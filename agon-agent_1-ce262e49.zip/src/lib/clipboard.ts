/**
 * Bulletproof clipboard copying utility
 * Works in secure contexts (HTTPS), non-secure contexts (HTTP),
 * and inside iframes (like preview panels) where navigator.clipboard might be blocked.
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  // 1. Try modern navigator.clipboard API if available and in secure context
  if (navigator.clipboard) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (err) {
      console.warn("navigator.clipboard.writeText failed, trying fallback:", err);
    }
  }

  // 2. Fallback: document.execCommand('copy') using a temporary textarea
  try {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    
    // Prevent scrolling and keep it hidden
    textArea.style.position = "fixed";
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.width = "2em";
    textArea.style.height = "2em";
    textArea.style.padding = "0";
    textArea.style.border = "none";
    textArea.style.outline = "none";
    textArea.style.boxShadow = "none";
    textArea.style.background = "transparent";
    textArea.style.opacity = "0";
    
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    // Execute copy command
    const successful = document.execCommand("copy");
    document.body.removeChild(textArea);
    
    if (successful) {
      return true;
    } else {
      throw new Error("execCommand copy returned false");
    }
  } catch (err) {
    console.error("Fallback copy to clipboard failed:", err);
    
    // 3. Last resort fallback: try selecting and copying using a prompt
    try {
      // If we are in an environment where copying is extremely restricted,
      // we can't do much, but at least we tried.
      return false;
    } catch (e) {
      return false;
    }
  }
}
