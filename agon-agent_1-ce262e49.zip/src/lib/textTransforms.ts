// Fancy Text Generator Core Engine

export interface TextStyle {
  id: string;
  name: string;
  category: 'unicode' | 'decorated' | 'case' | 'other';
  transform: (text: string) => string;
}

// 1. Math Alphanumeric helper for clean, bug-free mapping using ES6 fromCodePoint
function getMathAlphanumeric(
  char: string,
  offsetUpper: number,
  offsetLower: number,
  offsetDigit?: number,
  exceptions: Record<string, number> = {}
): string {
  if (exceptions[char] !== undefined) {
    return String.fromCodePoint(exceptions[char]);
  }
  
  const code = char.charCodeAt(0);
  
  // Uppercase A-Z
  if (code >= 65 && code <= 90) {
    return String.fromCodePoint(offsetUpper + (code - 65));
  }
  // Lowercase a-z
  if (code >= 97 && code <= 122) {
    return String.fromCodePoint(offsetLower + (code - 97));
  }
  // Digits 0-9
  if (offsetDigit !== undefined && code >= 48 && code <= 57) {
    return String.fromCodePoint(offsetDigit + (code - 48));
  }
  
  return char;
}

// Direct dictionaries for scattered unicode groups
const smallCapsMap: Record<string, string> = {
  'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ғ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 's', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ',
  'A': 'ᴀ', 'B': 'ʙ', 'C': 'ᴄ', 'D': 'ᴅ', 'E': 'ᴇ', 'F': 'ғ', 'G': 'ɢ', 'H': 'ʜ', 'I': 'ɪ', 'J': 'ᴊ', 'K': 'ᴋ', 'L': 'ʟ', 'M': 'ᴍ', 'N': 'ɴ', 'O': 'ᴏ', 'P': 'ᴘ', 'Q': 'ǫ', 'R': 'ʀ', 'S': 's', 'T': 'ᴛ', 'U': 'ᴜ', 'V': 'ᴠ', 'W': 'ᴡ', 'X': 'x', 'Y': 'ʏ', 'Z': 'ᴢ'
};

const greekMap: Record<string, string> = {
  'a': 'α', 'b': 'в', 'c': '¢', 'd': '∂', 'e': 'є', 'f': 'ƒ', 'g': 'g', 'h': 'н', 'i': 'ι', 'j': 'נ', 'k': 'к', 'l': 'ℓ', 'm': 'м', 'n': 'η', 'o': 'σ', 'p': 'ρ', 'q': 'q', 'r': 'я', 's': 'ѕ', 't': 'т', 'u': 'υ', 'v': 'ν', 'w': 'ω', 'x': 'χ', 'y': 'у', 'z': 'z',
  'A': 'α', 'B': 'в', 'C': '¢', 'D': '∂', 'E': 'є', 'F': 'ƒ', 'G': 'g', 'H': 'н', 'I': 'ι', 'J': 'נ', 'K': 'к', 'L': 'ℓ', 'M': 'м', 'N': 'η', 'O': 'σ', 'P': 'ρ', 'Q': 'q', 'R': 'я', 'S': 'ѕ', 'T': 'т', 'U': 'υ', 'V': 'ν', 'W': 'ω', 'X': 'χ', 'Y': 'у', 'Z': 'z'
};

const superscriptMap: Record<string, string> = {
  'a': 'ᵃ', 'b': 'ᵇ', 'c': 'ᶜ', 'd': 'ᵈ', 'e': 'ᵉ', 'f': 'ᶠ', 'g': 'ᵍ', 'h': 'ʰ', 'i': 'ⁱ', 'j': 'ʲ', 'k': 'ᵏ', 'l': 'ˡ', 'm': 'ᵐ', 'n': 'ⁿ', 'o': 'ᵒ', 'p': 'ᵖ', 'r': 'ʳ', 's': 'ˢ', 't': 'ᵗ', 'u': 'ᵘ', 'v': 'ᵛ', 'w': 'ʷ', 'x': 'ˣ', 'y': 'ʸ', 'z': 'ᶻ',
  'A': 'ᴬ', 'B': 'ᴮ', 'C': 'ᶜ', 'D': 'ᴰ', 'E': 'ᴱ', 'F': 'ᶠ', 'G': 'ᴳ', 'H': 'ᴴ', 'I': 'ᴵ', 'J': 'ᴶ', 'K': 'ᴷ', 'L': 'ᴸ', 'M': 'ᴹ', 'N': 'ᴺ', 'O': 'ᴼ', 'P': 'ᴾ', 'R': 'ᴿ', 'S': 'ˢ', 'T': 'ᵀ', 'U': 'ᵁ', 'V': 'ⱽ', 'W': 'ᵂ', 'X': 'ˣ', 'Y': 'ʸ', 'Z': 'ᶻ',
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾'
};

const subscriptMap: Record<string, string> = {
  'a': 'ₐ', 'e': 'ₑ', 'h': 'ₕ', 'i': 'ᵢ', 'j': 'ⱼ', 'k': 'ₖ', 'l': 'ₗ', 'm': 'ₘ', 'n': 'ₙ', 'o': 'ₒ', 'p': 'ₚ', 'r': 'ᵣ', 's': 'ₛ', 't': 'ₜ', 'u': 'ᵤ', 'v': 'ᵥ', 'x': 'ₓ',
  'A': 'ₐ', 'E': 'ₑ', 'H': 'ₕ', 'I': 'ᵢ', 'J': 'ⱼ', 'K': 'ₖ', 'L': 'ₗ', 'M': 'ₘ', 'N': 'ₙ', 'O': 'ₒ', 'P': 'ₚ', 'R': 'ᵣ', 'S': 'ₛ', 'T': 'ₜ', 'U': 'ᵤ', 'V': 'ᵥ', 'X': 'ₓ',
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉', '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎'
};

const upsideDownMap: Record<string, string> = {
  'a': 'ɐ', 'b': 'q', 'c': 'ɔ', 'd': 'p', 'e': 'ǝ', 'f': 'ɟ', 'g': 'ƃ', 'h': 'ɥ', 'i': 'ı', 'j': 'ɾ',
  'k': 'ʞ', 'l': 'l', 'm': 'ɯ', 'n': 'u', 'o': 'o', 'p': 'd', 'q': 'b', 'r': 'ɹ', 's': 's', 't': 'ʇ',
  'u': 'n', 'v': 'ʌ', 'w': 'ʍ', 'x': 'x', 'y': 'ʎ', 'z': 'z',
  'A': 'Ɐ', 'B': 'ᗺ', 'C': 'Ɔ', 'D': 'ᗡ', 'E': 'Ǝ', 'F': 'Ⅎ', 'G': '⅁', 'H': 'H', 'I': 'I', 'J': 'ſ',
  'K': 'ʞ', 'L': '˥', 'M': 'W', 'N': 'N', 'O': 'O', 'P': 'Ԁ', 'Q': 'Ό', 'R': 'ᴚ', 'S': 'S', 'T': '┴',
  'U': '∩', 'V': 'Λ', 'W': 'M', 'X': 'X', 'Y': '⅄', 'Z': 'Z',
  '0': '0', '1': 'Ɩ', '2': 'ᄅ', '3': 'Ɛ', '4': 'ㄣ', '5': 'ϛ', '6': '9', '7': 'ㄥ', '8': '8', '9': '6',
  '.': '˙', ',': '`', '?': '¿', '!': '¡', '\'': ',', '"': '„', '_': '‾', '&': '⅋', '(': ')', ')': '('
};

const mirrorMap: Record<string, string> = {
  'a': 'ɒ', 'b': 'd', 'c': 'ɔ', 'd': 'b', 'e': 'ɘ', 'f': 'ʇ', 'g': 'g', 'h': 'ʜ', 'i': 'i', 'j': 'į',
  'k': 'ʞ', 'l': 'l', 'm': 'm', 'n': 'ᴎ', 'o': 'o', 'p': 'q', 'q': 'p', 'r': 'ᴙ', 's': 'ꙅ', 't': 'ʇ',
  'u': 'υ', 'v': 'v', 'w': 'w', 'x': 'x', 'y': 'γ', 'z': 'z',
  'A': 'A', 'B': 'ᙄ', 'C': 'Ɔ', 'D': 'D', 'E': 'Ǝ', 'F': 'ᆿ', 'G': 'G', 'H': 'H', 'I': 'I', 'J': 'J',
  'K': 'K', 'L': '⅃', 'M': 'M', 'N': 'ᴎ', 'O': 'O', 'P': 'Գ', 'Q': 'Q', 'R': 'ᴙ', 'S': 'Ꙅ', 'T': 'T',
  'U': 'U', 'V': 'V', 'W': 'W', 'X': 'X', 'Y': 'Y', 'Z': 'Z',
  '0': '0', '1': '1', '2': 'S', '3': 'Ɛ', '4': 'Ⱶ', '5': 'ᄅ', '6': '∂', '7': '𝘓', '8': '8', '9': 'e'
};

// Zalgo characters for glitching
const zalgoUp = ['̍', '̎', '̄', '̅', '̿', '̑', '̆', '̐', '͒', '͗', '͑', '̇', '̈', '̊', '̃', '̾', '̽', '̚', '̕', '̛', '̀', '́', '͘', '̡', '̢', '̧', '̨', '̴', '̵', '̶', '͏', '͜', '͝', '͞', '͟', '҉'];
const zalgoMid = ['̕', '̛', '̀', '́', '͘', '̡', '̢', '̧', '̨', '̴', '̵', '̶', '͏', '͜', '͝', '͞', '͟', '҉', '̵', '̶', '̷', '̸', '͉', '͊', '͋', '͌', '͍', '͎', '͏', '͑', '͒', '͓', '͔', '͕', '͖', '͗', '͘', '͙', '͚', '͛'];
const zalgoDown = ['̖', '̗', '̘', '̙', '̜', '̝', '̞', '̟', '̠', '̤', '̥', '̦', '̩', '̪', '̫', '̬', '̭', '̮', '̯', '̰', '̱', '̲', '̳', '̹', '̺', '̻', '̼', 'ͅ', '͇', '͈', '͉', '͍', '͎', '͓', '͔', '͕', '͖', '͙', '͚', '͛'];

// Zalgo function
export function zalgo(text: string, options: { up: boolean, mid: boolean, down: boolean, intensity: number }): string {
  let result = '';
  const intensity = Math.min(Math.max(options.intensity, 1), 20); // Clamp 1-20
  
  for (let i = 0; i < text.length; i++) {
    result += text[i];
    
    // Don't glitch whitespace
    if (/\s/.test(text[i])) continue;

    const count = Math.floor(Math.random() * intensity);
    for (let j = 0; j < count; j++) {
      if (options.up && Math.random() > 0.3) {
        result += zalgoUp[Math.floor(Math.random() * zalgoUp.length)];
      }
      if (options.mid && Math.random() > 0.3) {
        result += zalgoMid[Math.floor(Math.random() * zalgoMid.length)];
      }
      if (options.down && Math.random() > 0.3) {
        result += zalgoDown[Math.floor(Math.random() * zalgoDown.length)];
      }
    }
  }
  return result;
}

// Combining marks decorators
const strikethroughMark = '\u0336';
const underlineMark = '\u0332';
const doubleUnderlineMark = '\u0333';
const slashthroughMark = '\u0338';
const waveUnderlineMark = '\u0330';
const bridgeAboveMark = '\u0346';
const arrowAboveMark = '\u0305';

function addCombiningMark(text: string, mark: string): string {
  return text.split('').map(char => char === ' ' ? ' ' : char + mark).join('');
}

// List of all style transforms
export const TEXT_STYLES: TextStyle[] = [
  {
    id: 'gothicBold',
    name: 'Gothic Bold (Fraktur)',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D538, 0x1D552)).join('')
  },
  {
    id: 'gothicReg',
    name: 'Gothic Regular',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D504, 0x1D51E, undefined, {
      'C': 0x212D, 'H': 0x210C, 'I': 0x2111, 'R': 0x211C, 'Z': 0x2128
    })).join('')
  },
  {
    id: 'scriptBold',
    name: 'Script Bold (Cursive)',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D4D0, 0x1D4EA)).join('')
  },
  {
    id: 'scriptReg',
    name: 'Script Regular',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D49C, 0x1D4B6, undefined, {
      'B': 0x212C, 'E': 0x2130, 'F': 0x2131, 'H': 0x210B, 'I': 0x2110, 'L': 0x2112, 'M': 0x2133, 'R': 0x211B,
      'e': 0x212F, 'g': 0x210A, 'o': 0x2134
    })).join('')
  },
  {
    id: 'doubleStruck',
    name: 'Double Struck (Blackboard)',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D56C, 0x1D586, 0x1D7D8, {
      'C': 0x2102, 'H': 0x210D, 'N': 0x2115, 'P': 0x2119, 'Q': 0x211A, 'R': 0x211D, 'Z': 0x2124
    })).join('')
  },
  {
    id: 'boldSerif',
    name: 'Bold Serif',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D400, 0x1D41A, 0x1D7CE)).join('')
  },
  {
    id: 'italicSerif',
    name: 'Italic Serif',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D434, 0x1D44E, undefined, {
      'h': 0x210E
    })).join('')
  },
  {
    id: 'boldItalicSerif',
    name: 'Bold Italic Serif',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D468, 0x1D482)).join('')
  },
  {
    id: 'boldSans',
    name: 'Bold Sans-Serif',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D5D4, 0x1D5EE, 0x1D7EC)).join('')
  },
  {
    id: 'italicSans',
    name: 'Italic Sans-Serif',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D608, 0x1D622)).join('')
  },
  {
    id: 'boldItalicSans',
    name: 'Bold Italic Sans-Serif',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D63C, 0x1D656)).join('')
  },
  {
    id: 'monospace',
    name: 'Monospace (Typewriter)',
    category: 'unicode',
    transform: (text) => text.split('').map(c => getMathAlphanumeric(c, 0x1D670, 0x1D68A, 0x1D7F6)).join('')
  },
  {
    id: 'bubbled',
    name: 'Bubbled Letters',
    category: 'unicode',
    transform: (text) => text.split('').map(c => {
      const code = c.charCodeAt(0);
      if (code >= 65 && code <= 90) return String.fromCodePoint(0x24B6 + (code - 65));
      if (code >= 97 && code <= 122) return String.fromCodePoint(0x24D0 + (code - 97));
      if (code === 48) return '⓪';
      if (code >= 49 && code <= 57) return String.fromCodePoint(0x2460 + (code - 49));
      return c;
    }).join('')
  },
  {
    id: 'bubbledFilled',
    name: 'Bubbled Filled',
    category: 'unicode',
    transform: (text) => text.split('').map(c => {
      const code = c.charCodeAt(0);
      if (code >= 65 && code <= 90) return String.fromCodePoint(0x1F150 + (code - 65));
      if (code >= 97 && code <= 122) return String.fromCodePoint(0x1F150 + (code - 97));
      if (code === 48) return '⓪';
      if (code >= 49 && code <= 57) return String.fromCodePoint(0x2776 + (code - 49));
      return c;
    }).join('')
  },
  {
    id: 'squared',
    name: 'Squared Letters',
    category: 'unicode',
    transform: (text) => text.split('').map(c => {
      const code = c.charCodeAt(0);
      if (code >= 65 && code <= 90) return String.fromCodePoint(0x1F130 + (code - 65));
      if (code >= 97 && code <= 122) return String.fromCodePoint(0x1F130 + (code - 97));
      return c;
    }).join('')
  },
  {
    id: 'squaredFilled',
    name: 'Squared Filled (Negative)',
    category: 'unicode',
    transform: (text) => text.split('').map(c => {
      const code = c.charCodeAt(0);
      if (code >= 65 && code <= 90) return String.fromCodePoint(0x1F170 + (code - 65));
      if (code >= 97 && code <= 122) return String.fromCodePoint(0x1F170 + (code - 97));
      return c;
    }).join('')
  },
  {
    id: 'smallCaps',
    name: 'Small Capital Letters',
    category: 'unicode',
    transform: (text) => text.split('').map(c => smallCapsMap[c] || c).join('')
  },
  {
    id: 'wide',
    name: 'Wide / Fullwidth',
    category: 'unicode',
    transform: (text) => text.split('').map(c => {
      const code = c.charCodeAt(0);
      if (code >= 65 && code <= 90) return String.fromCodePoint(0xFF21 + (code - 65));
      if (code >= 97 && code <= 122) return String.fromCodePoint(0xFF41 + (code - 97));
      if (code >= 48 && code <= 57) return String.fromCodePoint(0xFF10 + (code - 48));
      return c;
    }).join('')
  },
  {
    id: 'greek',
    name: 'Greek Aesthetic',
    category: 'unicode',
    transform: (text) => text.split('').map(c => greekMap[c] || c).join('')
  },
  {
    id: 'superscript',
    name: 'Tiny Superscript',
    category: 'unicode',
    transform: (text) => text.split('').map(c => superscriptMap[c] || c).join('')
  },
  {
    id: 'subscript',
    name: 'Tiny Subscript',
    category: 'unicode',
    transform: (text) => text.split('').map(c => subscriptMap[c] || c).join('')
  },
  {
    id: 'upsideDown',
    name: 'Upside Down Text',
    category: 'case',
    transform: (text) => {
      return text.split('').reverse().map(char => upsideDownMap[char] || char).join('');
    }
  },
  {
    id: 'mirror',
    name: 'Mirror / Reversed Text',
    category: 'case',
    transform: (text) => {
      return text.split('').reverse().map(char => mirrorMap[char] || char).join('');
    }
  },
  {
    id: 'strikethrough',
    name: 'Strikethrough Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, strikethroughMark)
  },
  {
    id: 'underline',
    name: 'Underline Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, underlineMark)
  },
  {
    id: 'doubleUnderline',
    name: 'Double Underline Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, doubleUnderlineMark)
  },
  {
    id: 'slashthrough',
    name: 'Slashthrough Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, slashthroughMark)
  },
  {
    id: 'waveUnderline',
    name: 'Wave Underline Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, waveUnderlineMark)
  },
  {
    id: 'bridgeAbove',
    name: 'Bridge Above Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, bridgeAboveMark)
  },
  {
    id: 'arrowAbove',
    name: 'Arrow Above Text',
    category: 'decorated',
    transform: (text) => addCombiningMark(text, arrowAboveMark)
  },
  {
    id: 'aestheticSpaced',
    name: 'Aesthetic Spaced',
    category: 'case',
    transform: (text) => text.split('').join(' ')
  },
  {
    id: 'doubleSpaced',
    name: 'D o u b l e   S p a c e d',
    category: 'case',
    transform: (text) => text.split('').join('  ')
  },
  {
    id: 'clapBack',
    name: 'Clap 👏 Back',
    category: 'decorated',
    transform: (text) => text.split(/\s+/).join(' 👏 ')
  },
  {
    id: 'emojiSpaced',
    name: 'Sparkle ✨ Spaced',
    category: 'decorated',
    transform: (text) => text.split(/\s+/).join(' ✨ ')
  },
  {
    id: 'sarcastic',
    name: 'sArCaStIc CaSe',
    category: 'case',
    transform: (text) => text.split('').map((char, index) => index % 2 === 0 ? char.toLowerCase() : char.toUpperCase()).join('')
  },
  {
    id: 'randomCase',
    name: 'rAnDoM CaSe',
    category: 'case',
    transform: (text) => text.split('').map(char => Math.random() > 0.5 ? char.toLowerCase() : char.toUpperCase()).join('')
  },
  {
    id: 'binary',
    name: 'Binary Code',
    category: 'other',
    transform: (text) => text.split('').map(char => char.charCodeAt(0).toString(2).padStart(8, '0')).join(' ')
  },
  {
    id: 'hex',
    name: 'Hexadecimal Code',
    category: 'other',
    transform: (text) => text.split('').map(char => char.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0')).join(' ')
  },
  {
    id: 'morse',
    name: 'Morse Code',
    category: 'other',
    transform: (text) => {
      const morseMap: Record<string, string> = {
        'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.', 'H': '....',
        'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---', 'P': '.--.',
        'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
        'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---', '3': '...--', '4': '....-',
        '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.', ' ': '/'
      };
      return text.toUpperCase().split('').map(char => morseMap[char] || char).join(' ');
    }
  }
];

// Decorator templates
export interface DecoratorTemplate {
  prefix: string;
  suffix: string;
  emoji?: string;
}

export const DECORATORS: DecoratorTemplate[] = [
  { prefix: "★彡 ", suffix: " 彡★", emoji: "★" },
  { prefix: "꧁༺ ", suffix: " ༻꧂", emoji: "꧁" },
  { prefix: "(っ◔◡◔)っ ♥ ", suffix: " ♥", emoji: "♥" },
  { prefix: "✧○ꊞ ", suffix: " ꊞ○✧", emoji: "✧" },
  { prefix: "░▒▓█ ", suffix: " █▓▒░", emoji: "░" },
  { prefix: "乂❤ ", suffix: " ❤乂", emoji: "❤" },
  { prefix: "✿°• ", suffix: " •°✿", emoji: "✿" },
  { prefix: "•°¯`•• ", suffix: " ••´¯°•", emoji: "•" },
  { prefix: "†_ ", suffix: " _†", emoji: "†" },
  { prefix: "⚡ ", suffix: " ⚡", emoji: "⚡" },
  { prefix: "⚔️ ", suffix: " ⚔️", emoji: "⚔️" },
  { prefix: "✨ ", suffix: " ✨", emoji: "✨" },
  { prefix: "🎀 ", suffix: " 🎀", emoji: "🎀" },
  { prefix: "👿 ", suffix: " 👿", emoji: "👿" },
  { prefix: "☯️ ", suffix: " ☯️", emoji: "☯️" },
  { prefix: "💀 ", suffix: " 💀", emoji: "💀" },
  { prefix: "🔥 ", suffix: " 🔥", emoji: "🔥" },
  { prefix: "❄️ ", suffix: " ❄️", emoji: "❄️" },
  { prefix: "👑 ", suffix: " 👑", emoji: "👑" },
  { prefix: "🛸 ", suffix: " 🛸", emoji: "🛸" },
  { prefix: "🎯 ", suffix: " 🎯", emoji: "🎯" },
];

export const NICKNAME_CATEGORIES = [
  { id: 'all', name: 'All Names' },
  { id: 'gaming', name: 'Gaming / Clan' },
  { id: 'aesthetic', name: 'Aesthetic' },
  { id: 'scary', name: 'Scary / Dark' },
  { id: 'cute', name: 'Cute / Kawaii' },
  { id: 'cyber', name: 'Cyberpunk / Tech' },
];

export const NICKNAMES_TEMPLATES = [
  // Gaming
  { template: "꧁༺ {name} ༻꧂", category: "gaming" },
  { template: "⚔️ 𝕾𝖑𝖆𝖞𝖊𝖗 {name} ⚔️", category: "gaming" },
  { template: "☠️ 𝕯𝖊𝖆𝖙𝖍 {name} ☠️", category: "gaming" },
  { template: "⚡ {name}_𝖁𝖔𝖑𝖙 ⚡", category: "gaming" },
  { template: "★彡 {name} 彡★", category: "gaming" },
  { template: "♛ {name} ♛", category: "gaming" },
  { template: "▄︻̷̿┻̿═━一 {name}", category: "gaming" },
  { template: "〖 {name} 〗", category: "gaming" },
  { template: "◥꧁ {name} ꧂◤", category: "gaming" },
  { template: "×𝓚𝓲𝓵𝓵𝓮𝓻 {name}×", category: "gaming" },
  
  // Aesthetic
  { template: "✧ {name} ✧", category: "aesthetic" },
  { template: "☾ {name} ☽", category: "aesthetic" },
  { template: "✨ 𝔢𝔱𝔥𝔢𝔯𝔢𝔞𝔩 {name} ✨", category: "aesthetic" },
  { template: "🌸 {name} 🌸", category: "aesthetic" },
  { template: "🎐 𝓅𝑒𝒶𝒸𝒽𝓎 {name} 🎐", category: "aesthetic" },
  { template: "🪐 {name} 🪐", category: "aesthetic" },
  { template: "🧸 {name} 🧸", category: "aesthetic" },
  { template: "☁️ {name} ☁️", category: "aesthetic" },
  { template: "˚₊· ͟͟͞͞➳❥ {name}", category: "aesthetic" },
  { template: "↳ {name} ｡.:*", category: "aesthetic" },

  // Scary
  { template: "☠︎☠︎ {name} ☠︎☠︎", category: "scary" },
  { template: "👿 𝔇𝔢𝔪𝔬𝔫 {name} 👿", category: "scary" },
  { template: "⛓️ {name} ⛓️", category: "scary" },
  { template: "🩸 𝖁𝖆𝖒𝖕𝖎𝖗𝖊 {name} 🩸", category: "scary" },
  { template: "☣️ 𝕿𝖔𝖝𝖎𝖈_{name} ☣️", category: "scary" },
  { template: "⚰️ {name} ⚰️", category: "scary" },
  { template: "🕷️ 𝖂𝖎𝖉𝖔𝖜 {name} 🕷️", category: "scary" },
  { template: "👻 𝕻𝖍𝖆𝖓𝖙𝖔𝖒 {name} 👻", category: "scary" },
  { template: "⚔️ 𝕲𝖗𝖎𝖒_{name}", category: "scary" },
  { template: "🕳️ 𝔙𝔬𝔦𝔡 {name}", category: "scary" },

  // Cute
  { template: "🧁 {name} 🧁", category: "cute" },
  { template: "🍓 {name} 🍓", category: "cute" },
  { template: "ʚ {name} ɞ", category: "cute" },
  { template: "₍ᐢ. .ᐢ₎ {name}", category: "cute" },
  { template: "♥ {name} ♥", category: "cute" },
  { template: "🍯 {name} 🍯", category: "cute" },
  { template: "🐾 {name} 🐾", category: "cute" },
  { template: "🎀 {name} 🎀", category: "cute" },
  { template: "🍭 𝔖𝔴𝔢𝔢𝔱 {name} 🍭", category: "cute" },
  { template: "✨ {name} ✨", category: "cute" },

  // Cyber
  { template: "🤖 {name}_𝕭𝖔𝖙", category: "cyber" },
  { template: "🛸 𝕮𝖞𝖇𝖊𝖗_{name} 🛸", category: "cyber" },
  { template: "💾 {name}.exe", category: "cyber" },
  { template: "🌐 𝕹𝖊𝖙_{name}", category: "cyber" },
  { template: "⚡ {name}_𝕹𝖊𝖔𝖓", category: "cyber" },
  { template: "🌌 𝕲𝖆𝖑𝖆𝖝𝖞_{name}", category: "cyber" },
  { template: "🧬 {name}_𝕳𝖞𝖇𝖗𝖎𝖉", category: "cyber" },
  { template: "🛰️ 𝕺𝖗𝖇🇮🇹_{name}", category: "cyber" },
  { template: "📟 {name}_𝕾𝖞𝖘", category: "cyber" },
  { template: "🔋 𝕮𝖍𝖆𝖗𝖌𝖊_{name}", category: "cyber" },
];

export const TEXT_ARTS = [
  {
    name: "Heart",
    art: "   ▄▄▄▄▄▄▄   ▄▄▄▄▄▄▄\n ▄█▀     ▀█▄█▀     ▀█▄\n █▌         █         ▐█\n ▐█                  █▌\n  ▀█▄              ▄█▀\n    ▀█▄          ▄█▀\n      ▀█▄      ▄█▀\n        ▀█▄  ▄█▀\n          ▀██▀"
  },
  {
    name: "Crying Meme",
    art: "     ┈┈┈┈┈┈┈┈┈┈┈┈┈┈\n     ┈┈┈┈╭━━━╮┈┈┈┈┈\n     ┈┈┈┈┃╭━╮┃┈┈┈┈┈\n     ┈┈┈┈┃╰━╯┃┈┈┈┈┈\n     ┈┈┈┈┃╭━━╯┈┈┈┈┈\n     ┈┈┈┈┃┃┈┈┈┈┈┈┈┈\n     ┈┈┈┈╰╯┈┈┈┈┈┈┈┈"
  },
  {
    name: "Sword",
    art: "         /| ________________\n   O|===|* >________________>\n         \\|"
  },
  {
    name: "Cat",
    art: " /\\_/\\\n( o.o )\n > ^ <"
  },
  {
    name: "Teddy Bear",
    art: " (\\_/)\n (•.•)\n/ > ♥"
  },
  {
    name: "Among Us Crewmate",
    art: "  ▄██████▄\n ▐█▀   ▀█▌\n ▐█     █▌\n  ▐█████▌\n  ▐█   █▌\n  ▐█   █▌"
  },
  {
    name: "Sparkles Border",
    art: "✼ •• ┈┈┈┈┈┈┈┈┈┈┈┈ •• ✼"
  },
  {
    name: "Flower Border",
    art: "✿°•┈┈┈┈┈┈┈┈┈┈┈┈•°✿"
  },
  {
    name: "Crown Border",
    art: "👑 ━━━━━━━━━━━━━━ 👑"
  },
  {
    name: "Retro Divider",
    art: "◄◄◄◄◄◄◄ ░▒▓█▓▒░ ►►►►►►►"
  }
];

export const SYMBOLS_CATEGORIES = [
  { id: 'stars', name: 'Stars & Sparkles', symbols: ['★', '☆', '✦', '✧', '✩', '✪', '✫', '✬', '✭', '✮', '✯', '✰', '☄', '🌣', '☼', '☀', '⚡', '🌌', '✨', '❇', '❈', '❉', '❊'] },
  { id: 'hearts', name: 'Hearts & Love', symbols: ['♥', '♡', 'ღ', '❣', '❤', '💖', '💗', '💓', '💞', '💕', '💟', '❣', '🖤', '🤍', '🤎', '🧡', '💛', '💚', '💙', '💜', '☙', '💑'] },
  { id: 'arrows', name: 'Arrows', symbols: ['←', '↑', '→', '↓', '↔', '↕', '↖', '↗', '↘', '↙', '↚', '↛', '↜', '↝', '↞', '↟', '↠', '↡', '↢', '↣', '↤', '↥', '↦', '↧', '↨', '↩', '↪', '↫', '↬', '↭', '↮', '↯', '↰', '↱', '↲', '↳', '↴', '↵', '↶', '↷', '↸', '↹', '↺', '↻', '⇎', '⇏', '⇐', '⇑', '⇒', '⇓', '⇔', '⇕', '⇖', '⇗', '⇘', '⇙', '⇚', '⇛', '⇜', '⇝', '⇞', '⇟', '⇠', '⇡', '⇢', '⇣', '⇤', '⇥', '⇦', '⇧', '⇨', '⇩', '⇪', '➔', '➘', '➙', '➚', '➛', '➜', '➝', '➞', '➟', '➠', '➡', '➢', '➣', '➤', '➥', '➦', '➧', '➨', '➩', '➪', '➫', '➬', '➭', '➮', '➯', '➱', '➲', '➳', '➴', '➵', '➶', '➷', '➸', '➹', '➺', '➻', '➼', '➽', '➾'] },
  { id: 'brackets', name: 'Brackets & Borders', symbols: ['【', '】', '〖', '〗', '〔', '〕', '『', '』', '「', '」', '《', '》', '〈', '〉', '（', '）', '［', '］', '｛', '｝', '❨', '❩', '❪', '❫', '❬', '❭', '❮', '❯', '❰', '❱', '❲', '❳', '❴', '❵', '⟅', '⟆', '⟦', '⟧', '⟨', '⟩', '⟪', '⟫', '⦃', '⦄', '⦅', '⦆', '⦇', '⦈', '⦉', '⦊', '⦋', '⦌', '⦍', '⦎', '⦏', '⦐', '⦑', '⦒', '⦓', '⦔', '    '] },
  { id: 'math', name: 'Math & Science', symbols: ['π', '∞', 'Σ', '√', '∫', '∬', '∭', '∮', '∯', '∰', '∱', '∲', '∳', '∆', '∇', '±', '×', '÷', '≈', '≠', '≤', '≥', '≡', '∝', '∞', '∟', '∠', '∡', '∢', '∣', '∤', '∥', '∦', '∧', '∨', '∩', '∪', '∴', '∵', '∶', '∷', '∸', '∹', '∺', '∻', '∼', '∽', '∾', '∿', '≀', '≁', '≂', '≃', '≄', '≅', '≆', '≇', '≈', '≉', '≊', '≋', '≌', '≍', '≎', '≏', '≐', '≑', '≒', '≓', '≔', '≕', '≖', '≗', '≘', '≙', '≚', '≛', '≜', '≝', '≞', '≟', '≠', '≡', '≢', '≣', '≤', '≥', '≦', '≧', '≨', '≩', '≪', '≫', '≬', '≭', '≮', '≯', '≰', '≱', '≲', '≳', '≴', '≵', '≶', '≷', '≸', '≲', '⊀', '⊁', '⊂', '⊃', '⊄', '⊅', '⊆', '⊇', '⊈', '⊉', '⊊', '⊋', '⊌', '⊍', '⊎', '⊏', '⊐', '⊑', '⊒', '⊓', '⊔', '⊕', '⊖', '⊗', '⊘', '⊙', '⊚', '⊛', '⊜', '⊝', '⊞', '⊟', '⊠', '⊡', '⊢', '⊣', '⊤', '⊥', '⊦', '⊧', '⊨', '⊩', '⊪', '⊫', '⊬', '⊭', '⊮', '⊯', '⊰', '⊱', '⊲', '⊳', '⊴', '⊵', '⊶', '⊷', '⊸', '▼', '▲', '◀', '▶', '◆', '◇', '◈', '◉', '◊', '○', '◌', '◍', '◎', '●', '◐', '◑', '◒', '◓', '◔', '◕', '◖', '◗', '◘', '◙', '◚', '◛', '◜', '◝', '◞', '◟', '◠', '◡', '◢', '◣', '◤', '◥', '◦', '◧', '◨', '◩', '◪', '◫', '◬', '◭', '◮', '◯'] },
  { id: 'music', name: 'Music & Audio', symbols: ['♪', '♫', '♩', '♬', '♭', '♮', '♯', '𝄞', '𝄢', '𝄡', '𝄪', '𝄫', '🎵', '🎶', '📻', '🎧', '🎤', '🎙', '🔊', '🔇', '🔈', '🔉'] },
  { id: 'chess', name: 'Chess & Cards', symbols: ['♔', '♕', '♖', '♗', '♘', '♙', '♚', '♛', '♜', '♝', '♞', '♟', '♠', '♡', '♢', '♣', '♤', '♥', '♦', '♧', '🃏', '🀄', '🎴'] },
  { id: 'currency', name: 'Currency Symbols', symbols: ['$', '€', '£', '¥', '₹', '₽', '₩', '₪', '₫', '₭', '₮', '₯', '₰', '₲', '₳', '₴', '₵', '₶', '₷', '₸', '₹', '₺', '₻', '₼', '₽', '₾', '₿', '🪙', '💵', '💴', '💶', '💷'] },
  { id: 'crosses', name: 'Crosses & Religion', symbols: ['†', '☨', '☩', '☥', '☦', '☧', '☫', '☬', '☸', '✡', '☯', '✝', '✞', '✟', '⛪', '🕌', '🕍', '🛕', '🕋', '⛩', '🕉'] },
  { id: 'weather', name: 'Weather & Sky', symbols: ['☀', '☁', '☂', '☃', '☄', '☼', '☽', '☾', '❄', '❅', '❆', '⚡', '🌀', '🌁', '🌫', '🌬', '🌪', '⛈', '🌧', '🌨', '🌦', '⛅', '🌤', '🌥', '🌙', '🪐', '🌠', '🌌'] },
  { id: 'misc', name: 'Miscellaneous', symbols: ['✉', '✍', '✎', '✏', '✐', '✑', '✒', '✂', '✁', '✃', '✄', '✆', '☎', '☏', '✇', '✈', '✉', '✌', '✍', '✎', '✏', '✐', '✑', '✒', '✓', '✔', '✗', '✘', '✕', '✖', '✚', '✜', '✛', '✦', '✧', '✨', '✩', '✪', '✫', '✬', '✭', '✮', '✯', '✰', '✻', '✼', '❄', '❅', '❆', '❇', '❈', '❉', '❊', '❣', '❤', '❥', '❦', '❧', '☙', '☯', '☮', '☸', '🖈', '📌', '📍', '📎', '🔒', '🔓', '🔑', '🔔', '🔕', '🔥', '💀', '💩', '👽', '👾', '🤖', '👻', '🎃', '😈', '👿', '👹', '👺', '🤡', '🐵', '🦊', '🐱', '🦁', '🐯', '🐼', '🐨', '🐻', '🐰', '🐭', '🐹', '🐷', '🐸', '🐙', '🐵', '🐔', '🐧', '🐦', '🐣', '🐤', '🐥', '🦆', '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🐛', '🦋', '🐌', '🐚', '🐞', '🐜', '🕷', '🕸', 'Scorpion', '🐢', '🐍', '🦎', '🐙', '🦑', 'lobster', 'crab', '🐡', '🐠', '🐟', '🐬', '🐳', '🐋', '🦈', '🐊', '🐅', '🐆', '🦓', '🦍', '🦧', '🦮', '🐕', '🐩', '🐈', '🐎', '🐖', '🐏', '🐑', '🐐', '🐪', '🐫', '🦒', '🐘', '🦏', '🦛', '🐭', '🐁', '🐀', '🐹', '🐰', '🐇', '🐿', '🦫', '🦔', '🦇', '🐻', '🐨', '🐼', '🦥', '🦦', '🦨', '🦕', '🦖', '🦅', '🦆', '🦢', '🦉', '🦤', '🦩', ' peacock', ' parrot'] }
];

export const KAOMOJIS = [
  {
    category: 'Happy / Cute',
    items: [
      '(っ◔◡◔)っ ♥', '(✿◠‿◠)', '(* ^ ω ^)', '(´ ∀ ` *)', '(o^▽^o)', '(⌒▽⌒)☆', '<(￣︶￣)>', 'ヽ(・∀・)ﾉ', '(´｡• ω •｡`)', '(￣ω￣)', 'g(_ _ )', '(o･ω･o)', '(＠＾◡＾)', '(o_ _)ﾉ彡☆', '(^人^)', '(ﾉ◕ヮ◕) Let\'s go', '(*°▽°*)', '╰(▔∀▔)╯', '( ˙꒳​˙ )', '(*¯︶¯*)', '(〃＾▽＾〃)', '＼(￣▽￣)／', 'o(>ω<)o', '(╯▽╰ )'
    ]
  },
  {
    category: 'Love / Kiss',
    items: [
      '(♡°▽°♡)', '(ღ˘⌣˘ღ)', '(´｡• ᵕ •｡`) ♡', '( ´ ▽ ` ).｡ｏ♡', '╰(*´︶`*)╯♡', '(*♡∀♡)', '(｡・//ε//・｡)', '(´,,•ω•,,)♡', '( ˘ ³˘)♥', '(♡ω♡)', '(￣ε￣＠)', '(❤ω❤)', '(*˘︶˘*).｡.:*♡', '(♡-_-♡)', '(─‿─)♡', '(*^^*)♡', '◌⑅⃝●♡⋆♡', '♡(｡- ω -)', '♡( ◡‿◡ )', '(◕‿◕)♡', '(^.^)♡'
    ]
  },
  {
    category: 'Angry / Mad',
    items: [
      '(＃`Д´)', '( ` ω ´ )', '(╬`益´)', '(╯°□°）╯︵ ┻━┻', '┻━┻ ︵ ヽ(°□°ヽ)', '(╬ Ò ﹏ Ó)', '(◣_◢)', '(ノ°益°)ノ', '(ง ͠° ͟ل͜ ͡°)ง', '凸(￣ヘ￣)', '٩(╬ʘ益ʘ╬)۶', '(凸ಠ益ಠ)凸', '＼(〇_ｏ)／', '(╬￣皿￣)凸', '( ╬ ◣ █ ◢ )', '┌∩┐(◣_◢)┌∩┐', '(ノಠ益ಠ)ノ', '(；￣Д￣)', '( `_ゝ´)', '(￣^￣)凸'
    ]
  },
  {
    category: 'Sad / Crying',
    items: [
      '(; ω ;)', '(´;;•ω•;;`)', '(┬┬﹏┬┬)', '( ﾟ，_ゝ｀)', '(ノ_<)', '(╯_╰)', '(´＿｀)', '(╯︵╰,)', '(｡╯3╰｡)', '(╥_╥)', '( T_T)＼(^-^ )', '(ಥ﹏ಥ)', '(。>︿<)_', '(._.)', '(︶︹︺)', '(._.`)', '(ㄒoㄒ)', '(;﹏;)', '( ◣_◢ )', '(-_-)'
    ]
  },
  {
    category: 'Surprised / Shock',
    items: [
      '(o_O)', '(⊙_⊙)', '(O_O;)', '(ﾟ_ﾟ)', '(ﾟДﾟ?!)', 'w(°ｏ°)w', '(^◇^;)', '(・_・;)', '(°ロ°) !', '(￣□￣;)', 'Σ(°△°|||)', '( º _ º )', '(⊙_☉)', 'Σ(￣□￣|||)', '( ﾟДﾟ)', '( ; ゜Д゜)', 'щ(゜ロ゜щ)', '((((；゜Д゜)))', '(*ﾟﾛﾟ)', '(´⊙o⊙`)'
    ]
  },
  {
    category: 'Shrug / Confused',
    items: [
      '┐(‘～`;)┌', '┐(￣∀￣)┌', '╮(︶▽︶)╭', '╮(￣_￣)╭', '┐(￣～￣)┌', '╮(─▽─)╭', '┐(´д`)┌', '┐(´∀｀)┌', '╮(￣ω￣)╭', '¯\\_(ツ)_/¯', '┐( ˘_˘ )┌', '┐( ∵ )┌', '╮(. ❛ ᴗ ❛.)╭', '╮(︶︿︶)╭', '┐(‘～`；)┌', '╮( ˘ ､ ˘ )╭', '┐( ˘ ､ ˘ )┌', '╮(︶▽︶)╭'
    ]
  },
  {
    category: 'Animals',
    items: [
      '(=^･ω･^=)', '(=^･ｪ･^=)', '(=①ω①=)', '( =ω=..)', '(=^‥^=)', '(=^･ω･^=) Let\'s purr', '(=; ｪ ;=)', '(^=◕ᴥ◕=^)', '∪･ω･∪', '∪･ｪ･∪', 'U^ｪ^U', '🐾', ' (´(ｪ)｀)', '( 🐻 )', '( 🐼 )', '(・⊝・)', '(｀⊝´)', '（・⊝・）', '（・⊝・∞）', '(=^ ◡ ^=)'
    ]
  },
  {
    category: 'Action / Fun',
    items: [
      '(•_•) ( •_•)>⌐■-■ (⌐■_■)', 'o(─_─)o', '(っಠ‿ಠ)っ', '＼(▽￣ \\) ﹏﹏ ( / ￣▽)/', '( ˘▽˘)っ♨', '(*￣▽￣)b', '(๑•̀ㅂ•́)و✧', '(o_ _)o', '( ￣ー￣)φ__', '( ^^) _旦~~', ' (。_。)', '( ;-_-)~ii', '( *^-^)ρ(^0^* )', '( ๑>ᴗ<๑)و', '୧( “ ☌ ω ☌ ” )୨', '୧| ͡° ͜ʖ ͡° |୨', 'ᕙ(  • ‿ •  )ᕗ', 'ᕦ( ͡° ͜ʖ ͡°)ᕤ', '(ง •̀_•́)ง'
    ]
  }
];
