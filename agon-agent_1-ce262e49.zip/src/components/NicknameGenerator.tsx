import React, { useState, useMemo } from 'react';
import { Gamepad2, Copy, Shuffle, Sparkles, Search, User } from 'lucide-react';
import { NICKNAMES_TEMPLATES, NICKNAME_CATEGORIES } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface NicknameGeneratorProps {
  text: string;
  onChangeText: (text: string) => void;
  onCopy: (copiedText: string) => void;
}

// Cool base names for randomization
const BASE_NAMES = [
  "Slayer", "Shadow", "Reaper", "Valkyrie", "Panda", "Luna", "Ethereal", "Volt", "Nexus", "Glitch",
  "Viper", "Phoenix", "Zeus", "Ares", "Karma", "Specter", "Echo", "Frost", "Nova", "Blaze",
  "Pika", "Bunny", "Mochi", "Boba", "Aesthetic", "Cosmic", "Neon", "Cyber", "Synapse", "Matrix"
];

export default function NicknameGenerator({ text, onChangeText, onCopy }: NicknameGeneratorProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const currentName = text || "Player1";

  // Generate random base name
  const handleRandomName = () => {
    const randomBase = BASE_NAMES[Math.floor(Math.random() * BASE_NAMES.length)];
    onChangeText(randomBase);
  };

  // Generate names using templates
  const generatedNicknames = useMemo(() => {
    return NICKNAMES_TEMPLATES.map((item, index) => {
      // Replace template placeholder
      const result = item.template.replace("{name}", currentName);
      return {
        id: index,
        result,
        category: item.category
      };
    });
  }, [currentName]);

  // Filter based on search and category
  const filteredNicknames = useMemo(() => {
    return generatedNicknames.filter(nick => {
      const matchesCategory = activeCategory === 'all' || nick.category === activeCategory;
      const matchesSearch = nick.result.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [generatedNicknames, activeCategory, searchQuery]);

  const handleCopy = async (nickText: string) => {
    await copyToClipboard(nickText);
    onCopy(nickText);
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-indigo-400 flex items-center gap-2 tracking-wide uppercase">
            <Gamepad2 size={16} className="text-indigo-400" />
            <span>Nickname & Tag Studio</span>
          </h3>
          <p className="text-[10px] text-slate-500 mt-0.5">Create styled names for games (PUBG, Roblox, Minecraft) & bios</p>
        </div>
        
        {/* Randomize Base Name */}
        <button
          onClick={handleRandomName}
          className="px-4 py-2 bg-slate-950 hover:bg-indigo-500/10 border border-slate-850 hover:border-indigo-500/20 rounded-xl text-xs font-bold text-slate-300 hover:text-indigo-400 flex items-center gap-2 transition-all cursor-pointer shadow-md self-start sm:self-auto"
        >
          <Shuffle size={12} />
          <span>Random Base Name</span>
        </button>
      </div>

      {/* Filter and Search controls */}
      <div className="flex flex-col md:flex-row gap-3.5 items-center justify-between p-4 bg-slate-950/45 border border-slate-850 rounded-xl">
        {/* Search */}
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tags..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500/85 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {NICKNAME_CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-2.5 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer whitespace-nowrap ${
                activeCategory === cat.id
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-500/10"
                  : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Results */}
      {filteredNicknames.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredNicknames.map((nick) => (
            <div
              key={nick.id}
              onClick={() => handleCopy(nick.result)}
              className="group relative bg-slate-950/40 border border-slate-850 hover:border-indigo-500/30 hover:bg-slate-900/40 rounded-xl p-3.5 flex items-center justify-between gap-3 cursor-pointer transition-all hover:scale-[1.01] hover:shadow-lg active:scale-95"
            >
              {/* Category tag */}
              <span className="absolute -top-2 left-3 px-1.5 py-0.5 bg-slate-900 border border-slate-800 text-[8px] font-bold text-slate-500 uppercase tracking-widest rounded">
                {nick.category}
              </span>

              {/* Styled Nickname */}
              <div className="text-xs font-semibold text-slate-200 truncate pr-2 pt-1 font-unicode">
                {nick.result}
              </div>

              {/* Copy action indicator */}
              <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-850 text-slate-500 group-hover:text-indigo-400 group-hover:border-indigo-500/20 transition-all shrink-0">
                <Copy size={12} />
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-12 bg-slate-950/20 border border-dashed border-slate-850 rounded-xl">
          <Sparkles size={24} className="text-slate-600 mx-auto mb-2 animate-pulse" />
          <h4 className="text-xs font-bold text-slate-400">No nicknames found</h4>
          <p className="text-[10px] text-slate-500 mt-1">Try changing your search query or choosing another category.</p>
        </div>
      )}
    </div>
  );
}
