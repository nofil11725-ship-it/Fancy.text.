import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Clipboard } from 'lucide-react';

export interface ToastItem {
  id: string;
  message: string;
  type?: 'success' | 'info';
}

interface ToastProps {
  toasts: ToastItem[];
  onRemove: (id: string) => void;
}

export default function Toast({ toasts, onRemove }: ToastProps) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 pointer-events-none max-w-sm w-full">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
            className="pointer-events-auto flex items-center gap-3 bg-slate-950/95 border border-indigo-500/30 text-white px-4 py-3.5 rounded-xl shadow-2xl shadow-indigo-500/10 backdrop-blur-md"
            onAnimationComplete={() => {
              // Auto-remove after 2.5s
              setTimeout(() => onRemove(toast.id), 2500);
            }}
          >
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-indigo-500/15 text-indigo-400 border border-indigo-500/25">
              <Check size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-slate-100">Copied to Clipboard!</p>
              <p className="text-[10px] text-slate-400 mt-0.5 truncate">{toast.message}</p>
            </div>
            <button 
              onClick={() => onRemove(toast.id)}
              className="text-slate-500 hover:text-slate-300 p-1 rounded transition-colors text-xs ml-2"
            >
              ✕
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
