import React, { useState, useEffect } from 'react';
import { Sliders, Copy, Shuffle, AlertTriangle, Skull } from 'lucide-react';
import { zalgo } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface ZalgoGlitcherProps {
  text: string;
  onCopy: (copiedText: string) => void;
}

export default function ZalgoGlitcher({ text, onCopy }: ZalgoGlitcherProps) {
  const [intensity, setIntensity] = useState(8);
  const [glitchUp, setGlitchUp] = useState(true);
  const [glitchMid, setGlitchMid] = useState(true);
  const [glitchDown, setGlitchDown] = useState(true);
  const [glitchedText, setGlitchedText] = useState('');

  const sourceText = text || "GLITCH TEXT";

  // Re-generate glitched text whenever text or settings change
  useEffect(() => {
    const glitched = zalgo(sourceText, {
      up: glitchUp,
      mid: glitchMid,
      down: glitchDown,
      intensity: intensity
    });
    setGlitchedText(glitched);
  }, [sourceText, intensity, glitchUp, glitchMid, glitchDown]);

  const handleCopy = async () => {
    await copyToClipboard(glitchedText);
    onCopy(glitchedText);
  };

  const handleRandomizeSettings = () => {
    setIntensity(Math.floor(Math.random() * 15) + 5);
    setGlitchUp(Math.random() > 0.3);
    setGlitchMid(Math.random() > 0.3);
    setGlitchDown(Math.random() > 0.3);
  };

  return (
    <div className="bg-slate-900/40 border border-red-500/10 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-red-400 flex items-center gap-2 tracking-wide uppercase">
            <Skull size={16} className="text-red-500 animate-pulse" />
            <span>Zalgo Glitch Studio</span>
          </h3>
          <p className="text-[10px] text-slate-500 mt-0.5">Generate corrupted, creepy, and distorted text</p>
        </div>
        <button
          onClick={handleRandomizeSettings}
          title="Randomize Glitch Settings"
          className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-red-500/30 text-slate-400 hover:text-red-400 transition-all cursor-pointer"
        >
          <Shuffle size={14} />
        </button>
      </div>

      {/* Controls & Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 p-4 bg-slate-950/40 border border-slate-850 rounded-xl">
        {/* Sliders */}
        <div className="flex flex-col gap-3.5">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
              <Sliders size={12} className="text-red-500" />
              <span>Glitch Intensity</span>
            </span>
            <span className="text-xs font-mono font-bold text-red-400 bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
              Lv. {intensity}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="20"
            value={intensity}
            onChange={(e) => setIntensity(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-red-500"
          />
          <span className="text-[9px] text-slate-500 leading-relaxed">
            Warning: High intensity may cause text to overlap surrounding page elements or lag older devices.
          </span>
        </div>

        {/* Direction Toggles */}
        <div className="flex flex-col gap-2.5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Glitch Directions</span>
          <div className="grid grid-cols-3 gap-2">
            {/* Up */}
            <button
              onClick={() => setGlitchUp(!glitchUp)}
              className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center ${
                glitchUp
                  ? "bg-red-500/10 border-red-500/30 text-red-400 shadow-md shadow-red-500/5"
                  : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
              }`}
            >
              Glitch Up
            </button>
            {/* Mid */}
            <button
              onClick={() => setGlitchMid(!glitchMid)}
              className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center ${
                glitchMid
                  ? "bg-red-500/10 border-red-500/30 text-red-400 shadow-md shadow-red-500/5"
                  : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
              }`}
            >
              Glitch Mid
            </button>
            {/* Down */}
            <button
              onClick={() => setGlitchDown(!glitchDown)}
              className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center ${
                glitchDown
                  ? "bg-red-500/10 border-red-500/30 text-red-400 shadow-md shadow-red-500/5"
                  : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
              }`}
            >
              Glitch Down
            </button>
          </div>
        </div>
      </div>

      {/* Output Display */}
      <div className="flex flex-col gap-3">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Live Glitched Output</span>
        <div className="relative group">
          {/* Main glitched container */}
          <div className="w-full min-h-[140px] bg-slate-950 border border-slate-850 rounded-xl p-6 text-slate-100 text-lg font-unicode overflow-x-auto break-words flex items-center justify-center text-center select-all selection:bg-red-500/30">
            {/* Padding around text to contain the vertical overflow of glitch marks */}
            <span className="inline-block py-10 px-4 leading-relaxed font-mono">
              {glitchedText}
            </span>
          </div>

          {/* Copy Button */}
          <div className="absolute top-3 right-3 flex items-center gap-2 opacity-80 group-hover:opacity-100 transition-opacity">
            <button
              onClick={handleCopy}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-red-500/25 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 border border-red-500/20"
            >
              <Copy size={12} />
              <span>Copy Glitched</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
