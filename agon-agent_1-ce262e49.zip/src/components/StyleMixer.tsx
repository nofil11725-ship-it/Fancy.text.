import React, { useState, useMemo, useEffect } from 'react';
import { Sliders, Copy, Shuffle, Sparkles, RefreshCw, Layers } from 'lucide-react';
import { TEXT_STYLES, TextStyle } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface StyleMixerProps {
  text: string;
  onCopy: (copiedText: string) => void;
}

// Available styles for custom letter mapping
const AVAILABLE_STYLES = [
  { id: 'standard', name: 'Standard' },
  { id: 'gothicBold', name: 'Gothic Bold' },
  { id: 'scriptBold', name: 'Script Bold' },
  { id: 'doubleStruck', name: 'Double Struck' },
  { id: 'boldSans', name: 'Bold Sans' },
  { id: 'monospace', name: 'Monospace' },
  { id: 'bubbled', name: 'Bubbled' },
  { id: 'squared', name: 'Squared' },
  { id: 'smallCaps', name: 'Small Caps' },
];

export default function StyleMixer({ text, onCopy }: StyleMixerProps) {
  const [mixMode, setMixMode] = useState<'presets' | 'custom'>('presets');
  const [activePreset, setActivePreset] = useState<string>('alternate');
  
  // Custom letter mapping state (maps 'A'-'Z' to a style id)
  const [customMap, setCustomMap] = useState<Record<string, string>>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('scribe_custom_font_map');
      if (saved) return JSON.parse(saved);
    }
    // Default: map everything to 'standard'
    const defaultMap: Record<string, string> = {};
    for (let i = 65; i <= 90; i++) {
      defaultMap[String.fromCharCode(i)] = 'standard';
    }
    return defaultMap;
  });

  // Selected letter for editing in custom map
  const [selectedLetter, setSelectedLetter] = useState<string>('A');

  // Save custom map to localStorage
  useEffect(() => {
    localStorage.setItem('scribe_custom_font_map', JSON.stringify(customMap));
  }, [customMap]);

  const sourceText = text || "Style Mixer Studio";

  // Predefined style lookups for quick transformation
  const styleLookup = useMemo(() => {
    const lookup: Record<string, (t: string) => string> = {};
    TEXT_STYLES.forEach(style => {
      lookup[style.id] = style.transform;
    });
    // Standard fallback
    lookup['standard'] = (t) => t;
    return lookup;
  }, []);

  // Helper to transform a single character using a style ID
  const transformChar = (char: string, styleId: string): string => {
    const transformFn = styleLookup[styleId];
    if (transformFn) {
      // transformFn expects full text, so we pass the single char
      return transformFn(char);
    }
    return char;
  };

  // Generate Mixed Text based on selected preset or custom map
  const mixedOutput = useMemo(() => {
    if (mixMode === 'custom') {
      // Custom mapping letter by letter
      return sourceText.split('').map(char => {
        const upper = char.toUpperCase();
        const styleId = customMap[upper];
        if (styleId && styleId !== 'standard') {
          // Keep original case but apply styled character
          const styled = transformChar(upper, styleId);
          return char === char.toLowerCase() ? styled.toLowerCase() : styled;
        }
        return char;
      }).join('');
    }

    // Presets Mode
    switch (activePreset) {
      case 'alternate': {
        // Alternate every letter between Gothic Bold and Bubbled
        return sourceText.split('').map((char, index) => {
          if (/\s/.test(char)) return char;
          const styleId = index % 2 === 0 ? 'gothicBold' : 'bubbled';
          return transformChar(char, styleId);
        }).join('');
      }
      case 'vowels': {
        // Style vowels in Script Bold, consonants in Monospace
        const vowels = ['A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u'];
        return sourceText.split('').map(char => {
          if (/\s/.test(char)) return char;
          const styleId = vowels.includes(char) ? 'scriptBold' : 'monospace';
          return transformChar(char, styleId);
        }).join('');
      }
      case 'wordAlternator': {
        // Alternate style word by word
        return sourceText.split(/\s+/).map((word, index) => {
          const styleId = index % 2 === 0 ? 'doubleStruck' : 'boldSans';
          return styleLookup[styleId] ? styleLookup[styleId](word) : word;
        }).join(' ');
      }
      case 'rainbow': {
        // Cycle through 5 different styles letter by letter
        const styles = ['gothicBold', 'bubbled', 'doubleStruck', 'monospace', 'smallCaps'];
        let charIndex = 0;
        return sourceText.split('').map(char => {
          if (/\s/.test(char)) return char;
          const styleId = styles[charIndex % styles.length];
          charIndex++;
          return transformChar(char, styleId);
        }).join('');
      }
      default:
        return sourceText;
    }
  }, [sourceText, mixMode, activePreset, customMap, styleLookup]);

  const handleCopy = async () => {
    await copyToClipboard(mixedOutput);
    onCopy(mixedOutput);
  };

  const handleResetCustomMap = () => {
    const defaultMap: Record<string, string> = {};
    for (let i = 65; i <= 90; i++) {
      defaultMap[String.fromCharCode(i)] = 'standard';
    }
    setCustomMap(defaultMap);
  };

  const handleRandomizeCustomMap = () => {
    const randomized: Record<string, string> = {};
    for (let i = 65; i <= 90; i++) {
      const char = String.fromCharCode(i);
      const randomStyle = AVAILABLE_STYLES[Math.floor(Math.random() * AVAILABLE_STYLES.length)].id;
      randomized[char] = randomStyle;
    }
    setCustomMap(randomized);
  };

  const handleLetterStyleSelect = (styleId: string) => {
    setCustomMap(prev => ({
      ...prev,
      [selectedLetter]: styleId
    }));
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-indigo-400 flex items-center gap-2 tracking-wide uppercase">
            <Layers size={16} className="text-indigo-400" />
            <span>Advanced Style Mixer</span>
          </h3>
          <p className="text-[10px] text-slate-500 mt-0.5">Mix multiple font styles together or design a custom letter-by-letter font map</p>
        </div>

        {/* Mode Selector */}
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-850">
          <button
            onClick={() => setMixMode('presets')}
            className={`px-3 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
              mixMode === 'presets'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Presets
          </button>
          <button
            onClick={() => setMixMode('custom')}
            className={`px-3 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
              mixMode === 'custom'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Font Designer
          </button>
        </div>
      </div>

      {/* Preset Mode Controls */}
      {mixMode === 'presets' ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-4 bg-slate-950/45 border border-slate-850 rounded-xl">
          <button
            onClick={() => setActivePreset('alternate')}
            className={`px-3 py-2.5 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center flex flex-col gap-1 items-center justify-center ${
              activePreset === 'alternate'
                ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-400"
                : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
            }`}
          >
            <span className="text-[10px] uppercase tracking-wider">Alternating</span>
            <span className="text-[9px] text-slate-500 font-normal">𝕲ⓞ𝕿ⓗ𝕴ⓒ + ⒷⓤⒷⓑⓛⒺ</span>
          </button>

          <button
            onClick={() => setActivePreset('vowels')}
            className={`px-3 py-2.5 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center flex flex-col gap-1 items-center justify-center ${
              activePreset === 'vowels'
                ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-400"
                : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
            }`}
          >
            <span className="text-[10px] uppercase tracking-wider">Vowels Only</span>
            <span className="text-[9px] text-slate-500 font-normal">𝓥ｏ𝔀𝓮𝓵𝓼 + 𝙼𝚘𝚗𝚘</span>
          </button>

          <button
            onClick={() => setActivePreset('wordAlternator')}
            className={`px-3 py-2.5 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center flex flex-col gap-1 items-center justify-center ${
              activePreset === 'wordAlternator'
                ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-400"
                : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
            }`}
          >
            <span className="text-[10px] uppercase tracking-wider">Word-by-Word</span>
            <span className="text-[9px] text-slate-500 font-normal">𝔸𝕝𝕥𝕖𝕣𝕟𝕒𝕥𝕖 𝗕𝗼𝗹𝗱</span>
          </button>

          <button
            onClick={() => setActivePreset('rainbow')}
            className={`px-3 py-2.5 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center flex flex-col gap-1 items-center justify-center ${
              activePreset === 'rainbow'
                ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-400"
                : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
            }`}
          >
            <span className="text-[10px] uppercase tracking-wider">Rainbow Mix</span>
            <span className="text-[9px] text-slate-500 font-normal">5 Styles Cycle</span>
          </button>
        </div>
      ) : (
        /* Custom Font Designer Mode Controls */
        <div className="flex flex-col gap-4 p-4 bg-slate-950/45 border border-slate-850 rounded-xl">
          {/* Quick Actions */}
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Custom Font Map Designer</span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleRandomizeCustomMap}
                className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 py-1 px-2 rounded hover:bg-indigo-500/10 transition-all cursor-pointer"
              >
                <Shuffle size={10} />
                <span>Randomize Map</span>
              </button>
              <button
                onClick={handleResetCustomMap}
                className="text-[10px] font-bold text-red-400 hover:text-red-300 flex items-center gap-1 py-1 px-2 rounded hover:bg-red-500/10 transition-all cursor-pointer"
              >
                <RefreshCw size={10} />
                <span>Reset Map</span>
              </button>
            </div>
          </div>

          {/* Letter Selection Grid */}
          <div className="flex flex-col gap-3">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">1. Select a Letter to customize</span>
            <div className="grid grid-cols-6 sm:grid-cols-9 md:grid-cols-13 gap-1.5">
              {Object.keys(customMap).map((letter) => {
                const styleId = customMap[letter];
                const isCustomized = styleId !== 'standard';
                return (
                  <button
                    key={letter}
                    onClick={() => setSelectedLetter(letter)}
                    className={`h-8 rounded font-mono text-xs font-bold transition-all cursor-pointer relative ${
                      selectedLetter === letter
                        ? "bg-indigo-600 text-white ring-2 ring-indigo-500/30 ring-offset-2 ring-offset-slate-950"
                        : isCustomized
                          ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                          : "bg-slate-950 border border-slate-850 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {letter}
                    {/* Small customized dot indicator */}
                    {isCustomized && (
                      <span className="absolute bottom-1 right-1 w-1 h-1 bg-indigo-400 rounded-full" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Style Assignment for Selected Letter */}
          <div className="flex flex-col gap-2 border-t border-slate-850 pt-3.5">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                2. Choose style for letter '<strong className="text-indigo-400">{selectedLetter}</strong>'
              </span>
              <span className="text-[10px] text-slate-400">
                Current style: <strong className="text-indigo-400 font-mono">{AVAILABLE_STYLES.find(s => s.id === customMap[selectedLetter])?.name}</strong>
              </span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
              {AVAILABLE_STYLES.map((style) => {
                const isSelected = customMap[selectedLetter] === style.id;
                // Preview character
                const charPreview = style.id === 'standard' ? selectedLetter : transformChar(selectedLetter, style.id);
                return (
                  <button
                    key={style.id}
                    onClick={() => handleLetterStyleSelect(style.id)}
                    className={`px-2 py-2 rounded text-[10px] font-semibold border transition-all cursor-pointer flex flex-col items-center gap-1 justify-center ${
                      isSelected
                        ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-500/10"
                        : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <span className="text-xs font-bold font-mono">{charPreview}</span>
                    <span className="text-[8px] text-slate-500 font-normal truncate max-w-full">{style.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Output Display */}
      <div className="flex flex-col gap-3">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Mixed Output Preview</span>
        <div className="relative group">
          {/* Main mixed container */}
          <div className="w-full min-h-[100px] bg-slate-950 border border-slate-850 rounded-xl p-5 text-slate-100 text-sm font-unicode break-all flex items-center justify-center text-center select-all selection:bg-indigo-500/30">
            <span className="leading-relaxed font-unicode text-base">
              {mixedOutput}
            </span>
          </div>

          {/* Copy Button */}
          <div className="absolute top-3 right-3 flex items-center gap-2 opacity-80 group-hover:opacity-100 transition-opacity">
            <button
              onClick={handleCopy}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-indigo-500/15 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 border border-indigo-500/20"
            >
              <Copy size={10} />
              <span>Copy Mixed</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
