import React from 'react';
import { X, Instagram, Twitter, MessageSquare, Gamepad2, Play } from 'lucide-react';

interface MockupPreviewProps {
  isOpen: boolean;
  onClose: () => void;
  text: string;
  styleName: string;
}

export default function MockupPreview({ isOpen, onClose, text, styleName }: MockupPreviewProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in">
      <div 
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Mockup Preview</span>
              <span className="text-xs font-normal px-2 py-0.5 bg-indigo-500/20 text-indigo-400 rounded-full border border-indigo-500/30">
                {styleName}
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">See how your fancy text looks on different platforms</p>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 bg-slate-900/50">
          {/* Instagram Bio Mockup */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-black">
            <div className="bg-zinc-900/80 px-4 py-2 text-xs font-semibold text-zinc-300 flex items-center gap-2 border-b border-zinc-800">
              <Instagram size={14} className="text-pink-500" />
              <span>Instagram Bio</span>
            </div>
            <div className="p-4 bg-black text-white font-sans max-w-sm mx-auto">
              <div className="flex items-center gap-4 mb-3">
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-yellow-500 via-red-500 to-purple-500 p-[2px]">
                  <div className="w-full h-full rounded-full bg-black border-2 border-black flex items-center justify-center text-xs text-zinc-500 font-bold">
                    AVATAR
                  </div>
                </div>
                <div className="flex-1 flex justify-around text-center text-sm">
                  <div>
                    <div className="font-bold">12</div>
                    <div className="text-xs text-zinc-400">Posts</div>
                  </div>
                  <div>
                    <div className="font-bold">1,420</div>
                    <div className="text-xs text-zinc-400">Followers</div>
                  </div>
                  <div>
                    <div className="font-bold">382</div>
                    <div className="text-xs text-zinc-400">Following</div>
                  </div>
                </div>
              </div>
              <div className="text-xs font-bold mb-1">Fancy Creator</div>
              <div className="text-xs text-zinc-400 mb-2">Digital Artist</div>
              {/* Bio Text */}
              <div className="text-xs whitespace-pre-wrap leading-relaxed border-l-2 border-pink-500 pl-2 py-0.5 text-zinc-100">
                {text || "Your fancy text here..."}
              </div>
              <div className="text-xs text-blue-400 mt-2 hover:underline cursor-pointer">
                fancy-text-studio.vercel.app
              </div>
            </div>
          </div>

          {/* Twitter / X Post Mockup */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-black">
            <div className="bg-zinc-900/80 px-4 py-2 text-xs font-semibold text-zinc-300 flex items-center gap-2 border-b border-zinc-800">
              <Twitter size={14} className="text-sky-400" />
              <span>Twitter / X Post</span>
            </div>
            <div className="p-4 bg-black text-white font-sans">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-[10px] text-zinc-400 font-bold">
                  USER
                </div>
                <div>
                  <div className="text-xs font-bold flex items-center gap-1">
                    <span>Scribe Studio</span>
                    <span className="w-3.5 h-3.5 bg-sky-500 rounded-full flex items-center justify-center text-[8px] text-white">✓</span>
                  </div>
                  <div className="text-[10px] text-zinc-500">@ScribeStudio • 2h</div>
                </div>
              </div>
              {/* Tweet Text */}
              <div className="text-sm whitespace-pre-wrap leading-relaxed text-zinc-100 mb-3">
                {text || "Your fancy text here..."}
              </div>
              <div className="text-[10px] text-zinc-500 border-b border-zinc-900 pb-3">
                10:24 AM • Oct 24, 2024 • <span className="text-zinc-300 font-bold">12.5K</span> Views
              </div>
              <div className="flex justify-between text-zinc-500 text-xs mt-3 px-2">
                <span className="hover:text-sky-400 cursor-pointer">💬 142</span>
                <span className="hover:text-green-400 cursor-pointer">🔁 82</span>
                <span className="hover:text-pink-500 cursor-pointer">❤️ 1.2K</span>
                <span className="hover:text-sky-400 cursor-pointer">🔖 45</span>
              </div>
            </div>
          </div>

          {/* Discord Message Mockup */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-[#313338]">
            <div className="bg-[#1e1f22] px-4 py-2 text-xs font-semibold text-zinc-300 flex items-center gap-2 border-b border-zinc-900">
              <MessageSquare size={14} className="text-[#5865F2]" />
              <span>Discord Message</span>
            </div>
            <div className="p-4 bg-[#313338] font-sans text-sm flex gap-4">
              <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center text-xs text-white font-bold shrink-0">
                DISC
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="font-semibold text-white hover:underline cursor-pointer text-xs">AestheticGamer</span>
                  <span className="bg-[#5865F2] text-[9px] text-white font-bold px-1 py-0.2 rounded uppercase">BOT</span>
                  <span className="text-[10px] text-zinc-400">Today at 3:42 PM</span>
                </div>
                {/* Discord Text */}
                <div className="text-zinc-300 text-xs whitespace-pre-wrap leading-relaxed break-words">
                  {text || "Your fancy text here..."}
                </div>
              </div>
            </div>
          </div>

          {/* Steam Name / Gaming Nickname Mockup */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-[#171a21]">
            <div className="bg-[#12141a] px-4 py-2 text-xs font-semibold text-zinc-300 flex items-center gap-2 border-b border-zinc-900">
              <Gamepad2 size={14} className="text-[#107c10]" />
              <span>Gaming Nickname (Steam Profile)</span>
            </div>
            <div className="p-5 bg-gradient-to-r from-[#1b2838] to-[#121a24] font-sans text-white">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="w-16 h-16 rounded border-2 border-blue-400 bg-zinc-800 p-0.5 shrink-0">
                  <div className="w-full h-full bg-zinc-900 flex items-center justify-center text-[10px] text-zinc-500 font-bold">
                    GAMER
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  {/* Styled Nickname */}
                  <h4 className="text-xl font-bold text-white truncate drop-shadow-md">
                    {text || "Your_Fancy_Nick"}
                  </h4>
                  <div className="text-xs text-blue-400 mt-1 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></span>
                    <span>Online</span>
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-1">Currently playing: Counter-Strike 2</div>
                </div>
                <div className="shrink-0 bg-slate-950/50 border border-slate-800 rounded-lg p-3 text-center sm:text-right min-w-[100px]">
                  <div className="text-xs text-zinc-400">Steam Level</div>
                  <div className="text-lg font-extrabold text-blue-400 flex items-center justify-center sm:justify-end gap-1">
                    <span className="w-6 h-6 rounded-full border border-blue-400 flex items-center justify-center text-xs">42</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* YouTube Video Title Mockup */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-zinc-900">
            <div className="bg-zinc-950 px-4 py-2 text-xs font-semibold text-zinc-300 flex items-center gap-2 border-b border-zinc-900">
              <Play size={14} className="text-red-600 fill-red-600" />
              <span>YouTube Video Title</span>
            </div>
            <div className="p-4 bg-zinc-900 font-sans text-white">
              <div className="aspect-video w-full max-w-sm bg-black rounded-lg mb-3 flex items-center justify-center text-xs text-zinc-500 font-bold border border-zinc-800">
                VIDEO THUMBNAIL PREVIEW
              </div>
              {/* Styled Title */}
              <h4 className="text-sm font-bold text-zinc-100 line-clamp-2 leading-snug">
                {text || "Your Styled Video Title Here!"} | INSANE GAMEPLAY! 🔥
              </h4>
              <div className="text-[10px] text-zinc-400 mt-1.5">
                245K views • 3 days ago
              </div>
              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-zinc-800">
                <div className="w-6 h-6 rounded-full bg-zinc-700 flex items-center justify-center text-[8px] font-bold text-zinc-400">CH</div>
                <div>
                  <div className="text-xs font-bold text-zinc-200">ProGamerVids</div>
                  <div className="text-[9px] text-zinc-400">1.2M subscribers</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-lg shadow-indigo-500/20 transition-all"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
}
