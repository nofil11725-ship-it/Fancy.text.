import React, { useState, useRef, useMemo } from 'react';
import { Keyboard, Copy, Trash2, Search, Sparkles } from 'lucide-react';
import { SYMBOLS_CATEGORIES } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface SymbolBoardProps {
  onCopy: (copiedText: string) => void;
}

export default function SymbolBoard({ onCopy }: SymbolBoardProps) {
  const [activeCategory, setActiveCategory] = useState<string>('stars');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [trayText, setTrayText] = useState<string>('');
  const trayInputRef = useRef<HTMLTextAreaElement>(null);

  // Get active category symbols
  const activeSymbols = useMemo(() => {
    const cat = SYMBOLS_CATEGORIES.find(c => c.id === activeCategory);
    return cat ? cat.symbols : [];
  }, [activeCategory]);

  // Filter symbols if search query exists
  const filteredSymbols = useMemo(() => {
    if (!searchQuery) return activeSymbols;
    
    // Search across all categories when searching
    let allMatching: string[] = [];
    SYMBOLS_CATEGORIES.forEach(cat => {
      cat.symbols.forEach(sym => {
        // Simple match, or if we can map common terms (e.g. "star" to ★)
        if (sym.includes(searchQuery) || cat.name.toLowerCase().includes(searchQuery.toLowerCase())) {
          if (!allMatching.includes(sym)) {
            allMatching.push(sym);
          }
        }
      });
    });
    return allMatching;
  }, [activeSymbols, searchQuery]);

  // Insert symbol at cursor position in the tray
  const handleSymbolClick = (symbol: string) => {
    const input = trayInputRef.current;
    if (input) {
      const start = input.selectionStart;
      const end = input.selectionEnd;
      const text = input.value;
      const before = text.substring(0, start);
      const after = text.substring(end, text.length);
      
      const newText = before + symbol + after;
      setTrayText(newText);
      
      // Reset cursor position after state update
      setTimeout(() => {
        input.focus();
        input.setSelectionRange(start + symbol.length, start + symbol.length);
      }, 10);
    } else {
      setTrayText(prev => prev + symbol);
    }
  };

  const handleCopyTray = async () => {
    if (!trayText) return;
    await copyToClipboard(trayText);
    onCopy(trayText);
  };

  const handleCopySingleSymbol = async (e: React.MouseEvent, symbol: string) => {
    e.stopPropagation(); // Stop from inserting into tray if they just wanted to copy
    await copyToClipboard(symbol);
    onCopy(symbol);
  };

  const handleClearTray = () => {
    setTrayText('');
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-5">
      {/* Header */}
      <div>
        <h3 className="text-sm font-bold text-indigo-400 flex items-center gap-2 tracking-wide uppercase">
          <Keyboard size={16} className="text-indigo-400" />
          <span>Symbol Keyboard</span>
        </h3>
        <p className="text-[10px] text-slate-500 mt-0.5">Click any symbol to copy it, or insert it into the Creator Tray below to design your own tags</p>
      </div>

      {/* Categories & Search Bar */}
      <div className="flex flex-col lg:flex-row gap-4 items-center justify-between p-4 bg-slate-950/45 border border-slate-850 rounded-xl">
        {/* Search */}
        <div className="relative w-full lg:w-64 shrink-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search symbols..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1 overflow-x-auto w-full pb-1 lg:pb-0 scrollbar-none">
          {SYMBOLS_CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                setSearchQuery(''); // Clear search when switching tabs
              }}
              className={`px-2.5 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer whitespace-nowrap ${
                activeCategory === cat.id && !searchQuery
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-500/10"
                  : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
              }`}
            >
              {cat.name.split(' ')[0]} {/* Shorten name for mobile */}
            </button>
          ))}
        </div>
      </div>

      {/* Symbols Grid */}
      <div className="bg-slate-950/30 border border-slate-850 rounded-xl p-4 min-h-[180px] max-h-[300px] overflow-y-auto">
        {filteredSymbols.length > 0 ? (
          <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 gap-2">
            {filteredSymbols.map((sym, i) => (
              <div
                key={i}
                onClick={() => handleSymbolClick(sym)}
                title="Click to insert in tray, right-click/long-press to copy directly"
                className="group relative h-10 w-full bg-slate-950 hover:bg-indigo-500/10 border border-slate-850 hover:border-indigo-500/30 rounded-lg flex items-center justify-center text-base text-slate-200 cursor-pointer transition-all hover:scale-105 active:scale-95"
              >
                <span>{sym}</span>
                {/* Floating direct copy indicator on hover */}
                <button
                  onClick={(e) => handleCopySingleSymbol(e, sym)}
                  title="Copy directly"
                  className="absolute -top-1.5 -right-1.5 opacity-0 group-hover:opacity-100 p-0.5 bg-indigo-600 text-white rounded border border-indigo-500 transition-opacity text-[8px] z-10 shadow-md"
                >
                  <Copy size={8} />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Sparkles size={20} className="text-slate-600 mx-auto mb-2 animate-pulse" />
            <h4 className="text-xs font-bold text-slate-400">No symbols found</h4>
          </div>
        )}
      </div>

      {/* Symbol Creator Tray */}
      <div className="flex flex-col gap-3 border-t border-slate-850 pt-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            <span>Symbol Assembly Tray</span>
          </span>
          {trayText && (
            <button
              onClick={handleClearTray}
              className="text-[10px] font-bold text-red-400 hover:text-red-300 flex items-center gap-1 py-1 px-2 rounded hover:bg-red-500/10 border border-transparent hover:border-red-500/20 transition-all cursor-pointer"
            >
              <Trash2 size={10} />
              <span>Clear Tray</span>
            </button>
          )}
        </div>

        <div className="relative">
          <textarea
            ref={trayInputRef}
            value={trayText}
            onChange={(e) => setTrayText(e.target.value)}
            placeholder="Click symbols above to insert them here, or type your text..."
            className="w-full h-20 bg-slate-950 border border-slate-850 focus:border-indigo-500/80 rounded-xl px-4 py-3 text-slate-100 placeholder-slate-600 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition-all resize-none font-sans"
          />

          {/* Tray Actions */}
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
            <button
              onClick={handleCopyTray}
              disabled={!trayText}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-indigo-500/15 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 disabled:opacity-40 disabled:hover:bg-indigo-600"
            >
              <Copy size={10} />
              <span>Copy Assembled</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
