import React, { useState, useMemo } from 'react';
import { Smile, Copy, Search, Sparkles } from 'lucide-react';
import { KAOMOJIS } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface KaomojiBoardProps {
  onCopy: (copiedText: string) => void;
}

export default function KaomojiBoard({ onCopy }: KaomojiBoardProps) {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Happy / Cute');

  // Filter kaomojis based on search and category
  const filteredKaomojis = useMemo(() => {
    if (search) {
      // Search across all categories
      let results: string[] = [];
      KAOMOJIS.forEach(cat => {
        cat.items.forEach(item => {
          if (item.includes(search) || cat.category.toLowerCase().includes(search.toLowerCase())) {
            if (!results.includes(item)) {
              results.push(item);
            }
          }
        });
      });
      return results;
    } else {
      const cat = KAOMOJIS.find(c => c.category === activeCategory);
      return cat ? cat.items : [];
    }
  }, [activeCategory, search]);

  const handleCopy = async (kaomoji: string) => {
    await copyToClipboard(kaomoji);
    onCopy(kaomoji);
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-5">
      {/* Header */}
      <div>
        <h3 className="text-sm font-bold text-indigo-400 flex items-center gap-2 tracking-wide uppercase">
          <Smile size={16} className="text-indigo-400" />
          <span>Kaomoji Library</span>
        </h3>
        <p className="text-[10px] text-slate-500 mt-0.5">Click any Japanese emoticon (Kaomoji) to copy it instantly to your clipboard</p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col lg:flex-row gap-4 items-center justify-between p-4 bg-slate-950/45 border border-slate-850 rounded-xl">
        {/* Search */}
        <div className="relative w-full lg:w-64 shrink-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search emoticons..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1 overflow-x-auto w-full pb-1 lg:pb-0 scrollbar-none">
          {KAOMOJIS.map(cat => (
            <button
              key={cat.category}
              onClick={() => {
                setActiveCategory(cat.category);
                setSearch(''); // Clear search when switching tabs
              }}
              className={`px-2.5 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer whitespace-nowrap ${
                activeCategory === cat.category && !search
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-500/10"
                  : "bg-slate-950 border-slate-850 text-slate-500 hover:text-slate-300"
              }`}
            >
              {cat.category.split(' ')[0]} {/* Short name for mobile */}
            </button>
          ))}
        </div>
      </div>

      {/* Kaomoji Grid */}
      <div className="bg-slate-950/30 border border-slate-850 rounded-xl p-4 min-h-[200px]">
        {filteredKaomojis.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {filteredKaomojis.map((kaomoji, i) => (
              <div
                key={i}
                onClick={() => handleCopy(kaomoji)}
                className="group relative bg-slate-950 hover:bg-indigo-500/10 border border-slate-850 hover:border-indigo-500/30 rounded-xl p-3.5 flex items-center justify-center text-xs font-semibold text-slate-200 cursor-pointer transition-all hover:scale-[1.02] active:scale-95 text-center min-h-[48px]"
              >
                <span>{kaomoji}</span>
                {/* Copy overlay icon */}
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-indigo-400 transition-opacity">
                  <Copy size={10} />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Sparkles size={20} className="text-slate-600 mx-auto mb-2 animate-pulse" />
            <h4 className="text-xs font-bold text-slate-400">No emoticons found</h4>
          </div>
        )}
      </div>
    </div>
  );
}
