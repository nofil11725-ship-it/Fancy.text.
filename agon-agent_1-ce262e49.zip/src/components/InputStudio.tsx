import React, { useState, useEffect } from 'react';
import { Trash2, Clipboard, Shuffle, Volume2, Mic, MicOff, Sparkles, Plus, RefreshCw } from 'lucide-react';
import { DECORATORS, DecoratorTemplate } from '../lib/textTransforms';

interface InputStudioProps {
  text: string;
  onChange: (text: string) => void;
  prefix: string;
  setPrefix: (prefix: string) => void;
  suffix: string;
  setSuffix: (suffix: string) => void;
  onCopy: (copiedText: string) => void;
}

const SAMPLE_TEXTS = [
  "Fancy Text Generator",
  "Hello World",
  "Aesthetic Vibes Only",
  "Scribe Text Studio",
  "Gamer Nickname",
  "Follow my socials",
  "Level Up Your Bio",
  "Cyberpunk 2077",
  "Be creative, be bold"
];

export default function InputStudio({
  text,
  onChange,
  prefix,
  setPrefix,
  suffix,
  setSuffix,
  onCopy
}: InputStudioProps) {
  const [localText, setLocalText] = useState(text);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [selectedDecorator, setSelectedDecorator] = useState<string>('none');

  // Sync localText with parent text (e.g. if randomized or set from another component)
  useEffect(() => {
    setLocalText(text);
  }, [text]);

  // Debounce localText updates to parent onChange to prevent typing lag and boost INP
  useEffect(() => {
    const handler = setTimeout(() => {
      if (localText !== text) {
        onChange(localText);
      }
    }, 120); // 120ms is imperceptible to humans but saves massive CPU cycles on mobile

    return () => clearTimeout(handler);
  }, [localText, onChange, text]);

  // Initialize Speech Recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const rec = new SpeechRecognition();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = 'en-US';

        rec.onstart = () => setIsListening(true);
        rec.onend = () => setIsListening(false);
        rec.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setLocalText(transcript);
          onChange(transcript);
        };
        rec.onerror = () => setIsListening(false);

        setRecognition(rec);
      }
    }
  }, [onChange]);

  const handleMicClick = () => {
    if (!recognition) return;
    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardText = await navigator.clipboard.readText();
      setLocalText(clipboardText);
      onChange(clipboardText);
    } catch (err) {
      // Fallback
      console.error("Failed to read clipboard:", err);
    }
  };

  const handleRandomize = () => {
    const randomText = SAMPLE_TEXTS[Math.floor(Math.random() * SAMPLE_TEXTS.length)];
    setLocalText(randomText);
    onChange(randomText);
  };

  const handleReadAloud = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(localText || "Type something to hear it");
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleDecoratorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedDecorator(val);
    if (val === 'none') {
      setPrefix('');
      setSuffix('');
    } else {
      const dec = DECORATORS.find(d => d.prefix === val || d.suffix === val);
      if (dec) {
        setPrefix(dec.prefix);
        setSuffix(dec.suffix);
      }
    }
  };

  const characterCount = localText.length;
  const wordCount = localText.trim() === '' ? 0 : localText.trim().split(/\s+/).length;

  return (
    <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl backdrop-blur-md flex flex-col gap-4">
      {/* Label and Counters */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-200 flex items-center gap-2 tracking-wide uppercase">
          <Sparkles size={16} className="text-indigo-400" />
          <span>Input Studio</span>
        </h2>
        <div className="flex gap-3 text-[10px] font-mono text-slate-400">
          <span className="px-2 py-0.5 bg-slate-800 rounded-md border border-slate-700/50">
            CHARS: <strong className="text-indigo-400">{characterCount}</strong>
          </span>
          <span className="px-2 py-0.5 bg-slate-800 rounded-md border border-slate-700/50">
            WORDS: <strong className="text-indigo-400">{wordCount}</strong>
          </span>
        </div>
      </div>

      {/* Main Textarea */}
      <div className="relative group">
        <textarea
          value={localText}
          onChange={(e) => setLocalText(e.target.value)}
          placeholder="Type or paste your text here..."
          className="w-full h-36 bg-slate-950/80 border border-slate-800 focus:border-indigo-500/80 rounded-xl px-4 py-3 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition-all resize-none font-sans"
        />
        {/* Absolute Quick Action Floating Buttons inside textarea */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity">
          {localText && (
            <button
              onClick={() => {
                setLocalText('');
                onChange('');
              }}
              title="Clear Text"
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-red-500/15 text-slate-400 hover:text-red-400 border border-slate-800/80 hover:border-red-500/20 transition-all shadow-md"
            >
              <Trash2 size={14} />
            </button>
          )}
          <button
            onClick={handlePaste}
            title="Paste Clipboard"
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-indigo-500/15 text-slate-400 hover:text-indigo-400 border border-slate-800/80 hover:border-indigo-500/20 transition-all shadow-md"
          >
            <Clipboard size={14} />
          </button>
          <button
            onClick={handleRandomize}
            title="Randomize Sample Text"
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-indigo-500/15 text-slate-400 hover:text-indigo-400 border border-slate-800/80 hover:border-indigo-500/20 transition-all shadow-md"
          >
            <Shuffle size={14} />
          </button>
          <button
            onClick={handleReadAloud}
            disabled={!localText}
            title="Read Text Aloud"
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-indigo-500/15 text-slate-400 hover:text-indigo-400 border border-slate-800/80 hover:border-indigo-500/20 transition-all shadow-md disabled:opacity-40 disabled:hover:bg-slate-900 disabled:hover:text-slate-400"
          >
            <Volume2 size={14} />
          </button>
          {recognition && (
            <button
              onClick={handleMicClick}
              title={isListening ? "Stop Dictation" : "Voice Input (Speech to Text)"}
              className={`p-1.5 rounded-lg border transition-all shadow-md ${
                isListening
                  ? "bg-red-500/20 text-red-400 border-red-500/40 animate-pulse"
                  : "bg-slate-900 hover:bg-indigo-500/15 text-slate-400 hover:text-indigo-400 border-slate-800/80 hover:border-indigo-500/20"
              }`}
            >
              {isListening ? <MicOff size={14} /> : <Mic size={14} />}
            </button>
          )}
        </div>
      </div>

      {/* Decorators & Custom Wrappers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {/* Quick Decorator Dropdown */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Symbol Decorator (Preset)
          </label>
          <select
            value={selectedDecorator}
            onChange={handleDecoratorChange}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500/80 transition-colors"
          >
            <option value="none">No Decorator</option>
            {DECORATORS.map((dec, i) => (
              <option key={i} value={dec.prefix}>
                {dec.prefix} text {dec.suffix}
              </option>
            ))}
          </select>
        </div>

        {/* Custom Decorators Inputs */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Custom Wrappers
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={prefix}
              onChange={(e) => {
                setPrefix(e.target.value);
                setSelectedDecorator('custom');
              }}
              placeholder="Prefix"
              className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500/80 transition-colors"
            />
            <input
              type="text"
              value={suffix}
              onChange={(e) => {
                setSuffix(e.target.value);
                setSelectedDecorator('custom');
              }}
              placeholder="Suffix"
              className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500/80 transition-colors"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
