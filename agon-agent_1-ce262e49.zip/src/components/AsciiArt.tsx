import React from 'react';
import { FileText, Copy, Sparkles } from 'lucide-react';
import { TEXT_ARTS } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface AsciiArtProps {
  onCopy: (copiedText: string) => void;
}

export default function AsciiArt({ onCopy }: AsciiArtProps) {
  const handleCopy = async (art: string) => {
    await copyToClipboard(art);
    onCopy(art);
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-5">
      {/* Header */}
      <div>
        <h3 className="text-sm font-bold text-indigo-400 flex items-center gap-2 tracking-wide uppercase">
          <FileText size={16} className="text-indigo-400" />
          <span>ASCII & Text Art</span>
        </h3>
        <p className="text-[10px] text-slate-500 mt-0.5">Copy beautiful pre-made text drawings, shapes, and borders for bios, chats, and forums</p>
      </div>

      {/* Grid of ASCII Arts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {TEXT_ARTS.map((art, index) => (
          <div
            key={index}
            className="group relative bg-slate-950 border border-slate-850 hover:border-indigo-500/30 rounded-xl p-4 flex flex-col justify-between gap-3 transition-all hover:shadow-lg"
          >
            {/* Art Name */}
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                {art.name}
              </span>
            </div>

            {/* Art Code Block */}
            <pre className="bg-slate-900/40 border border-slate-900 rounded-lg p-3.5 text-indigo-300 font-mono text-xs overflow-x-auto whitespace-pre leading-normal select-all select-none min-h-[80px] flex items-center justify-center text-center">
              {art.art}
            </pre>

            {/* Action */}
            <div className="flex justify-end border-t border-slate-900 pt-2.5">
              <button
                onClick={() => handleCopy(art.art)}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[10px] font-bold shadow-md shadow-indigo-500/15 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
              >
                <Copy size={10} />
                <span>Copy Art</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
