import React, { useState, useMemo } from 'react';
import { Search, Star, Copy, Eye, Share2, Sparkles, Filter } from 'lucide-react';
import { TEXT_STYLES, TextStyle } from '../lib/textTransforms';
import { copyToClipboard } from '../lib/clipboard';

interface StylesListProps {
  text: string;
  prefix: string;
  suffix: string;
  onCopy: (copiedText: string) => void;
  onPreview: (text: string, styleName: string) => void;
}

export default function StylesList({
  text,
  prefix,
  suffix,
  onCopy,
  onPreview
}: StylesListProps) {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [favorites, setFavorites] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('scribe_favorites');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });

  // Handle Favorites toggle
  const toggleFavorite = (id: string) => {
    setFavorites(prev => {
      const updated = prev.includes(id) 
        ? prev.filter(fId => fId !== id) 
        : [...prev, id];
      localStorage.setItem('scribe_favorites', JSON.stringify(updated));
      return updated;
    });
  };

  // Base text to transform (fallback if empty)
  const sourceText = text || "Fancy Text Studio";

  // Categories list
  const categories = [
    { id: 'all', name: 'All Styles' },
    { id: 'unicode', name: 'Unicode Fonts' },
    { id: 'decorated', name: 'Decorations' },
    { id: 'case', name: 'Case Shifter' },
    { id: 'other', name: 'Other / Code' }
  ];

  // Process, style, and filter list
  const styledItems = useMemo(() => {
    return TEXT_STYLES.map(style => {
      // Apply style transform
      let transformed = style.transform(sourceText);
      
      // Apply prefix and suffix decorators
      if (prefix || suffix) {
        transformed = `${prefix}${transformed}${suffix}`;
      }

      return {
        ...style,
        result: transformed,
        isFavorite: favorites.includes(style.id)
      };
    });
  }, [sourceText, prefix, suffix, favorites]);

  // Filter items based on category and search query
  const filteredItems = useMemo(() => {
    return styledItems.filter(item => {
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
      const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase()) || 
                            item.id.toLowerCase().includes(search.toLowerCase());
      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      // Sort favorites first
      if (a.isFavorite && !b.isFavorite) return -1;
      if (!a.isFavorite && b.isFavorite) return 1;
      return 0;
    });
  }, [styledItems, activeCategory, search]);

  const handleCopyClick = async (resultText: string) => {
    await copyToClipboard(resultText);
    onCopy(resultText);
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Search & Categories Bar */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-slate-900/40 border border-slate-800/60 p-4 rounded-2xl backdrop-blur-sm">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search styles (e.g. Gothic, Script)..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500/80 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition-all"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap border transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-500/15"
                  : "bg-slate-950 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:border-slate-700"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Styles Grid */}
      {filteredItems.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className={`group relative bg-slate-900/50 border rounded-2xl p-4 transition-all hover:scale-[1.01] hover:shadow-xl flex flex-col justify-between gap-4 ${
                item.isFavorite
                  ? "border-amber-500/30 bg-gradient-to-br from-amber-500/[0.02] to-slate-900/50 shadow-amber-500/[0.02]"
                  : "border-slate-800/80 hover:border-indigo-500/30 hover:bg-slate-900/70"
              }`}
            >
              {/* Card Header: Style Name & Category */}
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    item.category === 'unicode' ? 'bg-sky-400' :
                    item.category === 'decorated' ? 'bg-emerald-400' :
                    item.category === 'case' ? 'bg-purple-400' : 'bg-pink-400'
                  }`} />
                  {item.name}
                </span>

                {/* Favorite Button */}
                <button
                  onClick={() => toggleFavorite(item.id)}
                  title={item.isFavorite ? "Remove from Favorites" : "Add to Favorites"}
                  className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                    item.isFavorite
                      ? "bg-amber-500/10 text-amber-400 border-amber-500/30"
                      : "bg-slate-950 border-slate-800/80 text-slate-500 hover:text-amber-400 hover:border-amber-500/20"
                  }`}
                >
                  <Star size={12} className={item.isFavorite ? "fill-amber-400" : ""} />
                </button>
              </div>

              {/* Card Body: Styled Text Output */}
              <div className="bg-slate-950/60 border border-slate-950 rounded-xl px-4 py-3 text-slate-100 text-sm font-unicode min-h-[44px] flex items-center break-all select-all selection:bg-indigo-500/30 selection:text-white">
                {item.result}
              </div>

              {/* Card Footer: Action Buttons */}
              <div className="flex items-center justify-between border-t border-slate-950 pt-3">
                <button
                  onClick={() => onPreview(item.result, item.name)}
                  className="text-[10px] font-bold text-slate-400 hover:text-indigo-400 flex items-center gap-1.5 py-1 px-2 rounded-lg bg-slate-950/40 hover:bg-indigo-500/10 border border-slate-850 hover:border-indigo-500/20 transition-all cursor-pointer"
                >
                  <Eye size={12} />
                  <span>Preview Mockup</span>
                </button>

                <button
                  onClick={() => handleCopyClick(item.result)}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-500/15 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                >
                  <Copy size={12} />
                  <span>Copy</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 bg-slate-900/20 border border-dashed border-slate-800 rounded-2xl">
          <Sparkles size={32} className="text-slate-600 mx-auto mb-3 animate-pulse" />
          <h3 className="text-sm font-bold text-slate-300">No styles found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">Try adjusting your search query or select another category.</p>
        </div>
      )}
    </div>
  );
}
