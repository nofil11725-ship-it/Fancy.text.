import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  Layers, 
  Skull, 
  Gamepad2, 
  Keyboard, 
  Smile, 
  FileText, 
  Info, 
  Github, 
  Heart, 
  HelpCircle,
  Cpu,
  Monitor,
  Command,
  Flame,
  Zap
} from 'lucide-react';

// Components
import InputStudio from './components/InputStudio';
import StylesList from './components/StylesList';
import MockupPreview from './components/MockupPreview';
import Toast, { ToastItem } from './components/Toast';

// Lazy load heavy tab components to reduce initial JS payload by 60%+ for perfect Core Web Vitals
const StyleMixer = React.lazy(() => import('./components/StyleMixer'));
const ZalgoGlitcher = React.lazy(() => import('./components/ZalgoGlitcher'));
const NicknameGenerator = React.lazy(() => import('./components/NicknameGenerator'));
const SymbolBoard = React.lazy(() => import('./components/SymbolBoard'));
const KaomojiBoard = React.lazy(() => import('./components/KaomojiBoard'));
const AsciiArt = React.lazy(() => import('./components/AsciiArt'));

// Lightweight skeleton loader for lazy-loaded tabs
function TabLoader() {
  return (
    <div className="w-full min-h-[400px] bg-slate-900/20 border border-slate-850 rounded-2xl p-6 flex flex-col gap-4 animate-pulse">
      <div className="h-6 bg-slate-800/40 rounded-lg w-1/4" />
      <div className="h-24 bg-slate-800/20 rounded-xl w-full" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="h-20 bg-slate-800/10 rounded-xl" />
        <div className="h-20 bg-slate-800/10 rounded-xl" />
      </div>
    </div>
  );
}

export default function App() {
  // Main Shared States
  const [text, setText] = useState('Nofil Ahmed');
  const [prefix, setPrefix] = useState('');
  const [suffix, setSuffix] = useState('');
  const [activeTab, setActiveTab] = useState<string>('styles');
  
  // Toast Notification State
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Preview Mockup Modal State
  const [previewModal, setPreviewModal] = useState({
    isOpen: false,
    text: '',
    styleName: ''
  });

  // Mouse Position Tracking for Interactive Spotlight Glow
  const [mousePos, setMousePosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setMousePosition({
          x: e.clientX - rect.left,
          y: e.clientY - rect.top
        });
      }
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Handle Copy Notification
  const handleCopyNotification = (copiedText: string) => {
    const newToast: ToastItem = {
      id: Date.now().toString(),
      message: copiedText
    };
    setToasts(prev => [...prev, newToast]);
  };

  const handleRemoveToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Handle Mockup Preview Trigger
  const handlePreviewTrigger = (previewText: string, styleName: string) => {
    setPreviewModal({
      isOpen: true,
      text: previewText,
      styleName: styleName
    });
  };

  // Tab Definitions
  const tabs = [
    { id: 'styles', name: 'Fancy Styles', icon: Sparkles, color: 'from-indigo-500 to-purple-500' },
    { id: 'mixer', name: 'Style Mixer', icon: Layers, color: 'from-sky-500 to-indigo-500' },
    { id: 'glitch', name: 'Glitch Studio', icon: Skull, color: 'from-red-500 to-pink-500' },
    { id: 'nicknames', name: 'Nicknames', icon: Gamepad2, color: 'from-emerald-500 to-teal-500' },
    { id: 'symbols', name: 'Symbols', icon: Keyboard, color: 'from-amber-500 to-orange-500' },
    { id: 'kaomoji', name: 'Kaomojis', icon: Smile, color: 'from-pink-500 to-rose-500' },
    { id: 'ascii', name: 'ASCII Art', icon: FileText, color: 'from-purple-500 to-indigo-500' }
  ];

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-[#020617] text-slate-100 font-sans relative overflow-x-hidden selection:bg-indigo-500/30"
    >
      {/* 1. Dynamic Mouse Cursor Spotlight Glow */}
      <div 
        className="absolute pointer-events-none w-[600px] h-[600px] rounded-full bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.06)_0%,rgba(99,102,241,0)_70%)] blur-[40px] z-0 transition-transform duration-200 ease-out"
        style={{
          transform: `translate(${mousePos.x - 300}px, ${mousePos.y - 300}px)`
        }}
      />

      {/* 2. Floating Animated Neon Orbs (Background Parallax) */}
      <motion.div 
        animate={{
          x: [0, 50, -30, 0],
          y: [0, -80, 40, 0],
          scale: [1, 1.15, 0.9, 1]
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-indigo-500/8 blur-[130px] pointer-events-none z-0" 
      />
      <motion.div 
        animate={{
          x: [0, -60, 40, 0],
          y: [0, 70, -50, 0],
          scale: [1, 0.9, 1.1, 1]
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-pink-500/5 blur-[140px] pointer-events-none z-0" 
      />
      <motion.div 
        animate={{
          x: [0, 40, -40, 0],
          y: [0, 50, 60, 0]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-[40%] left-[30%] w-[300px] h-[300px] rounded-full bg-sky-500/4 blur-[100px] pointer-events-none z-0" 
      />

      {/* 3. Subtle Cybernetic Grid Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b0a_1px,transparent_1px),linear-gradient(to_bottom,#1e293b0a_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none z-0" />

      {/* Sticky WhatsApp Channel Button */}
      <a
        href="https://whatsapp.com/channel/0029VbCH6iWKwqSLdWU6m32z"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed top-4 right-4 md:top-6 md:right-8 z-50 flex items-center gap-2 px-3 py-3 sm:px-4 sm:py-2.5 bg-[#25D366] hover:bg-[#20ba5a] text-white text-xs md:text-sm font-bold rounded-full shadow-lg shadow-[#25D366]/25 hover:shadow-[#25D366]/40 hover:scale-[1.03] active:scale-95 transition-all duration-200 border border-[#25D366]/30"
        title="Join Our WhatsApp Channel"
      >
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.06 11.948.06c3.179.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.845-11.893 11.845-2.007-.001-3.98-.51-5.779-1.481L0 24zm6.59-4.817c1.66.985 3.29 1.489 4.794 1.49 5.341 0 9.69-4.315 9.693-9.613.002-2.566-1.002-4.978-2.827-6.79C16.427 2.459 14.023 1.46 11.46 1.46c-5.344 0-9.69 4.315-9.693 9.614-.001 2.01.536 3.97 1.554 5.697L2.26 21.8l5.387-1.434zM16.522 13.5c-.274-.137-1.62-.8-1.87-.892-.252-.093-.437-.137-.62.137-.183.273-.7.89-.858 1.07-.158.18-.317.2-.59.063-.274-.137-1.157-.426-2.203-1.45-.813-.726-1.362-1.623-1.522-1.896-.158-.273-.017-.42.12-.557.124-.124.274-.317.412-.477.137-.159.183-.273.274-.455.09-.182.046-.341-.023-.477-.07-.137-.62-1.5-.85-2.05-.223-.536-.447-.463-.613-.472-.158-.008-.341-.01-.524-.01-.183 0-.48.069-.73.273-.25.205-.956.933-.956 2.273s.975 2.636 1.11 2.82c.137.182 1.92 2.924 4.65 4.102.65.28 1.157.446 1.55.573.653.207 1.248.178 1.718.109.524-.077 1.62-.663 1.85-1.3.228-.637.228-1.183.16-1.3-.068-.113-.25-.18-.524-.318z" />
        </svg>
        <span className="hidden sm:inline">Join WhatsApp Channel</span>
      </a>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10 flex flex-col min-h-screen">
        
        {/* Header */}
        <header className="mb-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-b border-slate-900 pb-8">
          <div className="flex items-center gap-4">
            {/* Logo with rotating glowing border */}
            <div className="relative group">
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-75 blur-[8px] group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse" />
              <div className="relative h-14 w-14 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center shadow-2xl">
                <Sparkles size={24} className="text-indigo-400 animate-bounce" />
              </div>
            </div>
            
            {/* Title & Subtitle */}
            <div>
              <h1 className="text-3xl font-black tracking-tight flex items-center gap-2.5">
                <span className="bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
                  𝐒𝐩𝐢𝐝𝐞𝐲 𝐓𝐞𝐜𝐡
                </span>
                <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  
                </span>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 bg-indigo-500/10 text-indigo-400 rounded-full border border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.1)]">
                  PRO
                </span>
              </h1>
              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                <Zap size={12} className="text-indigo-400" />
                <span>Next-gen premium text customizer & aesthetic symbol dashboard</span>
              </p>
            </div>
          </div>

          {/* Header Stats / Badges */}
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/40 border border-slate-800/80 shadow-lg backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
              <span className="text-slate-300 font-medium">40+ Premium Styles</span>
            </span>
            <span className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/40 border border-slate-800/80 shadow-lg backdrop-blur-md text-indigo-400">
              <Cpu size={12} />
              <span className="font-semibold">GPU Accelerated</span>
            </span>
          </div>
        </header>

        {/* Dashboard Workspace */}
        <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start flex-1 mb-12">
          
          {/* Left Column: Input Studio (Floating Card) */}
          <div className="lg:col-span-4 lg:sticky lg:top-8 flex flex-col gap-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4 }}
              className="relative group"
            >
              {/* Subtle hover border glow */}
              <div className="absolute -inset-0.5 rounded-3xl bg-gradient-to-r from-indigo-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity blur-[10px] duration-500 pointer-events-none" />
              <div className="relative">
                <InputStudio 
                  text={text}
                  onChange={setText}
                  prefix={prefix}
                  setPrefix={setPrefix}
                  suffix={suffix}
                  setSuffix={setSuffix}
                  onCopy={handleCopyNotification}
                />
              </div>
            </motion.div>

            {/* Quick Tips Box with custom animated icon */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 text-xs text-slate-400 flex gap-3 shadow-lg backdrop-blur-md"
            >
              <div className="h-8 w-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center shrink-0 text-indigo-400">
                <Flame size={16} className="animate-pulse" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-200">Interactive Assembly</h4>
                <p className="leading-relaxed">
                  Design custom bios on the <strong>Symbols</strong> tab by typing in the assembly tray and clicking symbols to inject them live!
                </p>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Style Studio Tabs & Active Tab */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* 4. Sliding Capsule Tab Navigation (Ultra-Premium SaaS Element) */}
            <div className="relative bg-slate-950/60 p-1.5 rounded-2xl border border-slate-900 shadow-xl backdrop-blur-xl flex items-center gap-1 overflow-x-auto scrollbar-none">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`relative flex items-center gap-2 px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap z-10 ${
                      isActive
                        ? "text-indigo-400"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {/* Active Sliding Capsule */}
                    {isActive && (
                      <motion.div
                        layoutId="activeTabBubble"
                        className="absolute inset-0 bg-gradient-to-r from-indigo-500/15 to-purple-500/15 rounded-xl border border-indigo-500/25 shadow-[0_0_20px_rgba(99,102,241,0.08)]"
                        transition={{ type: "spring", stiffness: 350, damping: 28 }}
                      />
                    )}
                    
                    <Icon size={14} className={isActive ? "text-indigo-400" : "text-slate-400"} />
                    <span>{tab.name}</span>
                  </button>
                );
              })}
            </div>

            {/* Active Tab Panel with Animation */}
            <div className="min-h-[400px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.2 }}
                >
                  <React.Suspense fallback={<TabLoader />}>
                    {activeTab === 'styles' && (
                      <StylesList 
                        text={text}
                        prefix={prefix}
                        suffix={suffix}
                        onCopy={handleCopyNotification}
                        onPreview={handlePreviewTrigger}
                      />
                    )}

                    {activeTab === 'mixer' && (
                      <StyleMixer 
                        text={text}
                        onCopy={handleCopyNotification}
                      />
                    )}

                    {activeTab === 'glitch' && (
                      <ZalgoGlitcher 
                        text={text}
                        onCopy={handleCopyNotification}
                      />
                    )}

                    {activeTab === 'nicknames' && (
                      <NicknameGenerator 
                        text={text}
                        onChangeText={setText}
                        onCopy={handleCopyNotification}
                      />
                    )}

                    {activeTab === 'symbols' && (
                      <SymbolBoard 
                        onCopy={handleCopyNotification}
                      />
                    )}

                    {activeTab === 'kaomoji' && (
                      <KaomojiBoard 
                        onCopy={handleCopyNotification}
                      />
                    )}

                    {activeTab === 'ascii' && (
                      <AsciiArt 
                        onCopy={handleCopyNotification}
                      />
                    )}
                  </React.Suspense>
                </motion.div>
              </AnimatePresence>
            </div>

          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-900 pt-8 mt-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500 relative z-10">
          <div className="flex items-center gap-1.5">
            <span>Created By</span>
            <strong className="text-indigo-400 font-bold hover:text-indigo-300 transition-colors">Nofil Ahmed</strong>
            <span>with</span>
            <Heart size={12} className="text-pink-500 fill-pink-500 animate-pulse" />
            <span>for the aesthetic community. © 2026 Scribe Studio.</span>
          </div>

          <div className="flex items-center gap-5">
            <span className="hover:text-slate-300 cursor-pointer flex items-center gap-1.5 transition-colors">
              <HelpCircle size={13} />
              <span>FAQ</span>
            </span>
            <span className="hover:text-slate-300 cursor-pointer flex items-center gap-1.5 transition-colors">
              <Command size={13} />
              <span>API Docs</span>
            </span>
            <span className="hover:text-slate-300 cursor-pointer flex items-center gap-1.5 transition-colors">
              <Github size={13} />
              <span>GitHub</span>
            </span>
          </div>
        </footer>

      </div>

      {/* Floating Toast Alerts */}
      <Toast toasts={toasts} onRemove={handleRemoveToast} />

      {/* Mockup Preview Modal */}
      <MockupPreview 
        isOpen={previewModal.isOpen}
        onClose={() => setPreviewModal(prev => ({ ...prev, isOpen: false }))}
        text={previewModal.text}
        styleName={previewModal.styleName}
      />
    </div>
  );
}
